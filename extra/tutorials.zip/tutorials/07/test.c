// Testprogramm, User mode
//

int main ();
int exit ();
int syscall1 (int eax);
int syscall2 (int eax, int ebx);
int syscall3 (int eax, int ebx, int ecx);
int syscall4 (int eax, int ebx, int ecx, int edx);
void printf (char *s);
void readline (char *s);
int fork ();

int main () {
  printf ("Hallo - User Mode!\n");
  int pid = fork ();
  for (;;) {
    if (pid == 0) printf ("S");  // Sohn
    else          printf ("V");  // Vater
  }
}


int syscall1 (int eax) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax) );
  return result ;
}

int syscall2 (int eax, int ebx) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax), "b" (ebx) );
  return result ;
}

int syscall3 (int eax, int ebx, int ecx) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax), "b" (ebx), "c" (ecx) );
  return result ;
}

int syscall4 (int eax, int ebx, int ecx, int edx) {
  int result;
  asm ( "int $0x80" : "=a" (result) 
                    : "a" (eax), "b" (ebx), "c" (ecx), "d" (edx) );
  return result ;
}

#define __NR_printf   1
#define __NR_readline 2

void printf (char *s) {
  syscall2 (__NR_printf, (unsigned int)s);
}

void readline (char *s) {
  syscall2 (__NR_readline, (unsigned int)s);
}

int fork () {
  int retval;
  asm ( " \
    .intel_syntax noprefix; \
    mov eax, 2; \
    int 0x80; \
    mov %0, ebx; \
    .att_syntax; " : "=r"(retval) :
    : "eax", "ebx");
  return retval;
}
