#define false 0
#define true 1
#define MEM_SIZE 1024*1024*64        // 64 MByte
#define MAX_ADDRESS MEM_SIZE-1       // last valid physical address
#define PAGE_SIZE 4096               // Intel: 4K pages
#define NUMBER_OF_FRAMES MEM_SIZE/PAGE_SIZE
#define asm __asm__
#define volatile __volatile__
#define NULL ((void*) 0)
#define IRQ_TIMER      0
#define IRQ_KBD        1
#define IRQ_SLAVE      2     // Here the slave PIC connects to master
#define IRQ_COM2       3
#define IRQ_COM1       4
#define IRQ_FDC        6
#define IRQ_IDE       14     // primary IDE controller; secondary has IRQ 15
// I/O Addresses of the two programmable interrupt controllers
#define IO_PIC_MASTER_CMD   0x20  // Master (IRQs 0-7), command register
#define IO_PIC_MASTER_DATA  0x21  // Master, control register

#define IO_PIC_SLAVE_CMD    0xA0  // Slave (IRQs 8-15), command register
#define IO_PIC_SLAVE_DATA   0xA1  // Slave, control register
#define END_OF_INTERRUPT  0x20
#define KEY_UP     191
#define KEY_DOWN   192
#define KEY_LEFT   193
#define KEY_RIGHT  194
#define MAX_SYSCALLS 0x8000         // max syscall number: 0x7fff
#define __NR_printf   1
#define __NR_kpeek    0x7001
#define __NR_kpoke    0x7002
#define MAX_ADDR_SPACES 1024
#define BINARY_LOAD_ADDRESS      0x0
#define TOP_OF_USER_MODE_STACK   0xb0000000
#define TOP_OF_KERNEL_MODE_STACK 0xc0000000
#define AS_FREE   0
#define AS_USED   1
#define AS_DELETE 2
#define MAX_THREADS 1024
#define PROGSIZE 32768
#define KERNEL_STACK_PAGES 4
#define KERNEL_STACK_SIZE PAGE_SIZE * KERNEL_STACK_PAGES
typedef unsigned int addr_space_id;
struct gdt_entry {
  unsigned int limit_low   : 16;
  unsigned int base_low    : 16;
  unsigned int base_middle :  8;
  unsigned int access      :  8;
  unsigned int flags       :  4;
  unsigned int limit_high  :  4;
  unsigned int base_high   :  8;
};

struct gdt_ptr {
  unsigned int limit       : 16;
  unsigned int base        : 32;
} __attribute__((packed));
typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int undocumented   :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_table_desc;

typedef struct { page_table_desc ptds[1024]; } page_directory;
typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int dirty          :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_desc;

typedef struct { page_desc pds[1024]; } page_table;
typedef unsigned int boolean;
struct idt_entry {
    unsigned int addr_low  : 16;   // lower 16 bits of address
    unsigned int gdtsel    : 16;   // use which GDT entry?
    unsigned int zeroes    :  8;   // must be set to 0
    unsigned int type      :  4;   // type of descriptor
    unsigned int flags     :  4;
    unsigned int addr_high : 16;   // higher 16 bits of address
} __attribute__((packed));
struct idt_ptr {
    unsigned int limit   : 16;
    unsigned int base    : 32;
} __attribute__((packed));
struct regs {
  unsigned int gs, fs, es, ds;
  unsigned int edi, esi, ebp, esp, ebx, edx, ecx, eax;
  unsigned int int_no, err_code;
  unsigned int eip, cs, eflags, useresp, ss;
};
typedef struct {
  void         *pd;        // pointer to the page directory
  int          pid;        // process ID (if used by a process; -1 if not)
  short        status;     // are we using this address space?
  unsigned int memstart;   // first address below 0xc000.0000
  unsigned int memend;     // last  address below 0xc000.0000
  unsigned int stacksize;  // size of user mode stack
  unsigned int kstack_pt;  // stack page table (for kernel stack)
  unsigned int refcount;   // how many threads use this address space?
} address_space;
typedef int thread_id;
typedef struct regs context_t;

typedef struct {
  thread_id     tid;         // thread id
  thread_id     ppid;        // parent process
  int           state;       // state of the process
  context_t     regs;        // context
  unsigned int  esp0;        // kernel stack pointer
  unsigned int  eip;         // program counter
  unsigned int  ebp;         // base pointer
  addr_space_id addr_space;  // memory usage
  boolean used;
} TCB;
typedef struct {
  unsigned int prev_tss    : 32;  // unused: previous TSS
  unsigned int esp0, ss0   : 32;  // ESP and SS to load when we switch to ring 0
  long long u1, u2         : 64;  // unused: esp1, ss1, esp2, ss2 for rings 1 and 2
  unsigned int cr3         : 32;  // unused: page directory
  unsigned int eip, eflags : 32;
  unsigned int eax, ecx, edx, ebx, esp, ebp, esi, edi, es, cs, ss, ds, fs, gs : 32;
                                  // unused (dynamic, filled by CPU)
  long long u3             : 64;  // unused: ldt, trap, iomap
} __attribute__((packed)) tss_entry_struct;
struct gdt_entry gdt[6];
struct gdt_ptr gp;
page_directory kernel_pd     __attribute__ ((aligned (4096)));
page_table kernel_pt         __attribute__ ((aligned (4096)));
page_table kernel_pt_ram[16] __attribute__ ((aligned (4096)));

page_directory* current_pd = &kernel_pd;
page_table*     current_pt = &kernel_pt;
unsigned int free_frames = NUMBER_OF_FRAMES;
char place_for_ftable[NUMBER_OF_FRAMES/8];
unsigned int* ftable = (unsigned int*)(&place_for_ftable);
unsigned int VIDEO = 0xb8000 + 0xc0000000;
int paging_ready = false;
int posx, posy;
struct idt_entry idt[256] = { 0 };
struct idt_ptr idtp;
void *interrupt_handlers[16] = { 0 };
char *exception_messages[] = {
  "Division By Zero",       "Debug",                        //  0,  1
  "Non Maskable Interrupt", "Breakpoint",                   //  2,  3
  "Into Detected Overflow", "Out of Bounds",                //  4,  5
  "Invalid Opcode",         "No Coprocessor",               //  6,  7
  "Double Fault",           "Coprocessor Segment Overrun",  //  8,  9
  "Bad TSS",                "Segment Not Present",          // 10, 11
  "Stack Fault",            "General Protection Fault",     // 12, 13
  "Page Fault",             "Unknown Interrupt",            // 14, 15
  "Coprocessor Fault",      "Alignment Check",              // 16, 17
  "Machine Check",                                          // 18
  "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
  "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
  "Reserved", "Reserved", "Reserved"                        // 19..31
};
unsigned long int ticks = 0;
char scancode_table[128] = { 
  /*  0.. 9 */    0,  27, '1', '2', '3', '4', '5', '6', '7', '8',
  /* 10..19 */   '9', '0', '-', '=', '\b',       /* Backspace */
                 '\t', /* Tab */   'q', 'w', 'e', 'r',  
  /* 20..29 */   't', 'z', 'u', 'i', 'o', 'p', '[', ']', 
                 '\n', /* Enter */  0, /* Control */
  /* 30..39 */   'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',
  /* 40..49 */   '\'', '`', 0, /* Left shift */  '\\', 'y', 'x', 
                 'c', 'v', 'b', 'n',
  /* 50..59 */   'm', ',', '.', '/', 0, /* Right shift */
                 '*', 0, /* Alt */  ' ', /* Space bar */
                 0, /* CapsLock */  0, /* F1 */
  /* 60..69 */   0, 0, 0, 0, 0, 0, 0, 0, 0, /* F2..F10 */
                 0, /* NumLock */
  /* 70..79 */   0, /* Scroll Lock */   0, /* Home key */
                 KEY_UP, 0, /* Page Up */
                 '-', KEY_LEFT, 0, KEY_RIGHT,
                 '+', 0, /* End */
  /* 80..89 */   KEY_DOWN, 0, /* Page Down */
                 0, /* Insert Key */    0, /* Delete */
                 0, 0, 0, 0, /* F11 */  0, /* F12 */   0,
  /* 90..127     not defined */
};   // Scan Codes
short int pos = 0;                  // Puffer-Position
short int unread = 0;               // Anzahl "frischer" Zeichen
char buffer[256] = { 0 };           // Eingabe-Puffer
void *syscall_table[MAX_SYSCALLS];
address_space address_spaces[MAX_ADDR_SPACES] = { 0 };
addr_space_id current_as = 0;  // global variable: current address space
TCB thread_table[MAX_THREADS];
int next_pid = 1;
volatile int current_task;
tss_entry_struct tss_entry;
unsigned char usermodeprog[] = {


    /// HIER LOESUNG EINTRAGEN


};
#define KMAP(pd,frame) \
  fill_page_desc (pd, true, true, false, false, frame)
#define KMAPD(ptd, frame) \
  fill_page_table_desc (ptd, true, true, false, frame)
#define INDEX_FROM_BIT(b) (b/32)   // 32 bits in an unsigned int
#define OFFSET_FROM_BIT(b) (b%32)
#define PHYSICAL(x) ((x)+0xd0000000)
#define PEEK(addr) (*(unsigned char *)(addr))
#define FILL_IDT(i) \
  fill_idt_entry (i, (unsigned int)isr##i, 0x08, 0b1110, 0b1110)
#define MAKE_MULTIPLE_OF_PAGESIZE(x)  x = ((x+PAGE_SIZE-1)/PAGE_SIZE) \
  * PAGE_SIZE
#define UMAP(pd,frame)    fill_page_desc (pd, true, true, true,  false, frame)
#define UMAPD(ptd, frame) fill_page_table_desc (ptd, true, true, true,  frame)
extern void gdt_flush();
void fill_gdt_entry (int num, unsigned long base, 
  unsigned long limit, unsigned char access, unsigned char gran);
void gdt_install ();
page_table_desc* fill_page_table_desc (page_table_desc *ptd, 
  unsigned int present, unsigned int writeable, 
  unsigned int user_accessible, unsigned int frame_addr);
page_desc* fill_page_desc (page_desc *pd, unsigned int present,
  unsigned int writeable, unsigned int user_accessible,
  unsigned int dirty, unsigned int frame_addr);
static void set_frame (unsigned int frame_addr);
static void clear_frame (unsigned int frame_addr);
static unsigned int test_frame (unsigned int frame_addr);
int request_new_frame ();
void release_frame (unsigned int frameaddr);
unsigned int pageno_to_frameno (unsigned int pageno);
unsigned int* request_new_page (int need_more_pages);
void release_page (unsigned int pageno);
void *memset  (void *dest, char val,  int count);
void *memsetw (void *dest, short val, int count);
extern int printf(const char *format, ...);
void kputch (char c);
extern void uartputc (int c);
void clrscr ();
void *memcpy (void *dest, const void *src, int count);
void *strncpy (void *dest, const void *src, int count);
void hexdump (unsigned int start, unsigned int end);
unsigned char  inportb (unsigned short port);
unsigned short inportw (unsigned short port);
void outportb (unsigned short port, unsigned char data);
void outportw (unsigned short port, unsigned short data);
void fill_idt_entry (unsigned char num, unsigned long address, 
    unsigned short gdtsel, unsigned char flags, unsigned char type);
extern void irq0(), irq1(), irq2(),  irq3(),  irq4(),  irq5(),  irq6(),  irq7();
extern void irq8(), irq9(), irq10(), irq11(), irq12(), irq13(), irq14(), irq15();
static void set_irqmask (unsigned short mask);
static void enable_interrupt (int number);
unsigned short get_irqmask ();
void install_interrupt_handler (int irq, void (*handler)(struct regs *r));
extern void idt_load ();
extern void isr0(),  isr1(),  isr2(),  isr3(),  isr4(),  isr5(),  
   isr6(),  isr7(),  isr8(),  isr9(),  isr10(), isr11(), isr12(), 
   isr13(), isr14(), isr15(), isr16(), isr17(), isr18(), isr19(), 
   isr20(), isr21(), isr22(), isr23(), isr24(), isr25(), isr26(), 
   isr27(), isr28(), isr29(), isr30(), isr31(), isr128();
void fault_handler (struct regs *r);
void keyboard_handler (struct regs *r);
void timer_handler (struct regs *r);
void kreadline (char *s, int len);
void install_syscall_handler (int syscallno, void *syscall_handler);
void syscall_printf (struct regs *r);
void syscall_kpeek (struct regs *r);
void syscall_kpoke (struct regs *r);
int syscall1 (int eax);
int syscall2 (int eax, int ebx);
int syscall3 (int eax, int ebx, int ecx);
int syscall4 (int eax, int ebx, int ecx, int edx);
void userprint (char *s);
int  kpeek (unsigned int address);
void kpoke (unsigned int address, unsigned char value);
int get_free_address_space ();
int create_new_address_space (int initial_ram, int initial_stack);
int as_map_page_to_frame (int as, unsigned int pageno, unsigned int frameno);
void activate_address_space (addr_space_id id);
unsigned int mmu_p (addr_space_id id, unsigned int pageno);
unsigned int mmu (addr_space_id id, unsigned int vaddress);
int register_new_tcb (addr_space_id as_id);
static void write_tss (int num, unsigned short ss0, unsigned int esp0);
extern void tss_flush();
extern void cpu_usermode (unsigned int address, unsigned int stack);   
// assembler
void fill_gdt_entry(int num, unsigned long base, unsigned long limit,
                  unsigned char access, unsigned char gran) {
  /* Setup the descriptor base address */
  gdt[num].base_low = (base & 0xFFFF);            // 16 bits
  gdt[num].base_middle = (base >> 16) & 0xFF;     //  8 bits
  gdt[num].base_high = (base >> 24) & 0xFF;       //  8 bits

  /* Setup the descriptor limits */
  gdt[num].limit_low  = (limit & 0xFFFF);         // 16 bits
  gdt[num].limit_high = ((limit >> 16) & 0x0F);   //  4 bits

  /* Finally, set up the granularity and access flags */
  gdt[num].flags = gran & 0xF;
  gdt[num].access = access;
}

void gdt_install() {
  gp.limit = (sizeof(struct gdt_entry) * 6) - 1;
  gp.base = (int) &gdt;

  fill_gdt_entry(0, 0, 0, 0, 0);    // NULL descriptor

  // code segment
  fill_gdt_entry(1, 0, 0xFFFFFFFF, 0b10011010, 0b1100 /* 0xCF */);

  // data segment
  fill_gdt_entry(2, 0, 0xFFFFFFFF, 0b10010010, 0b1100 /* 0xCF */);

  fill_gdt_entry (3, 0, 0xFFFFFFFF, 0xFA, 0b1100);
  fill_gdt_entry (4, 0, 0xFFFFFFFF, 0xF2, 0b1100);
  write_tss (5, 0x10, 0xC0000000);  // spaeter!
  gdt_flush();
  tss_flush();
}
page_desc* fill_page_desc (page_desc *pd, unsigned int present,
  unsigned int writeable, unsigned int user_accessible,
  unsigned int dirty, unsigned int frame_addr) {

  memset (pd, 0, sizeof(pd));
  
  pd->present = present;
  pd->writeable = writeable;
  pd->user_accessible = user_accessible;
  pd->dirty = dirty;
  pd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
  return pd;
};

page_table_desc* fill_page_table_desc (page_table_desc *ptd, 
  unsigned int present, unsigned int writeable, 
  unsigned int user_accessible, unsigned int frame_addr) {

  memset (ptd, 0, sizeof(ptd));
  
  ptd->present = present;
  ptd->writeable = writeable;
  ptd->user_accessible = user_accessible;
  ptd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
  return ptd;
};
static void set_frame (unsigned int frame_addr) {
  unsigned int frame = frame_addr / PAGE_SIZE;
  unsigned int index  = INDEX_FROM_BIT  (frame);
  unsigned int offset = OFFSET_FROM_BIT (frame);
  ftable[index] |= (1 << offset);
}

static void clear_frame (unsigned int frame_addr) {
  unsigned int frame = frame_addr / PAGE_SIZE;
  unsigned int index  = INDEX_FROM_BIT  (frame);
  unsigned int offset = OFFSET_FROM_BIT (frame);
  ftable[index] &= ~(1 << offset);
}

static unsigned int test_frame (unsigned int frame_addr) {
  // returns true if frame is in use (false if frame is free)
  unsigned int frame = frame_addr / PAGE_SIZE;
  unsigned int index  = INDEX_FROM_BIT  (frame);
  unsigned int offset = OFFSET_FROM_BIT (frame);
  return ((ftable[index] & (1 << offset)) >> offset);
}
int request_new_frame () {
  unsigned int frameid;
  boolean found=false;
  for (frameid = 0; frameid < NUMBER_OF_FRAMES; frameid++) {
    if ( !test_frame (frameid*4096) ) {
      found=true;
      break;   // frame found
    };
  }
  if (found) {
    memset ((void*)PHYSICAL(frameid << 12), 0, PAGE_SIZE);
    set_frame (frameid*4096);
    free_frames--;
    return frameid;
  } else {
    return -1;
  }
};

void release_frame (unsigned int frameaddr) {
  if ( test_frame (frameaddr) ) {
    // only do work if frame is marked as used
    clear_frame (frameaddr);
    free_frames++;
  };
};
unsigned int pageno_to_frameno (unsigned int pageno) {
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  if ( ! current_pd->ptds[pdindex].present ) {
    return -1;       // we don't have that page table
  } else {
    // get the page table
    page_table* pt = (page_table*)
      ( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
    if ( pt->pds[ptindex].present ) {
      return pt->pds[ptindex].frame_addr;
    } else {
      return -1;     // we don't have that page
    };
  };    
};
unsigned int* request_new_page (int need_more_pages) {
  unsigned int newframeid = request_new_frame ();
  if (newframeid == -1) { return NULL; }  // exit if no frame was found
  unsigned int pageno = -1;
  for (unsigned int i=0xc0000; i<1024*1024; i++) {
    if ( pageno_to_frameno (i) == -1 ) {
      pageno = i;
      break;       // end loop, unmapped page was found
    };
  };

  if ( pageno == -1 ) {
    return NULL;   // we found no page -- whole 4 GB are mapped???
  };
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  page_table* pt;
  if (/* ptindex == 0 && */ ! current_pd->ptds[pdindex].present) {
    // last entry! // create a new page table in the reserved frame
    page_table* pt = (page_table*) PHYSICAL(newframeid<<12);
    memset (pt, 0, PAGE_SIZE);


    // KMAPD ( &(current_pd->ptds[pdindex]), newframeid << 12 );
    
    
    addr_space_id asid;
    page_directory* tmp_pd;
    for (asid=0; asid<1024; asid++) {
      if (address_spaces[asid].status == AS_USED) {  // is this address space in use?
        tmp_pd = address_spaces[asid].pd;
        KMAPD ( &(tmp_pd->ptds[pdindex]), newframeid << 12 );
      }
    }

    newframeid = request_new_frame ();  // get yet another frame
    if (newframeid == -1) {
      return NULL;                      // exit if no frame was found
      // note: we're not removing the new page table since we assume
      // it will be used soon anyway
    }
  };
  pt = (page_table*)( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
  // finally: enter the frame address
  KMAP ( &(pt->pds[ptindex]), newframeid * PAGE_SIZE );

  // invalidate cache entry
  asm volatile ("invlpg %0" : : "m"(*(char*)(pageno<<12)) );

  memset ((unsigned int*) (pageno*4096), 0, 4096);
  return ((unsigned int*) (pageno*4096));
}
void release_page (unsigned int pageno) {
  int frameno = pageno_to_frameno (pageno);  // we will need this later
  if ( frameno == -1 )  { return; }          // exit if no such page
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  page_table* pt;
  pt = (page_table*)
    ( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
  // write null page descriptor
  memset (&(pt->pds[ptindex]), 0, 4);
  fill_page_desc (&(pt->pds[ptindex]), false, false, false, false, 0);
  release_frame (frameno<<12);   // expects an address, not an ID
  asm volatile ("invlpg %0" : : "m"(*(char*)(pageno<<12)) );
  // gdt_flush ();
};
void *memset (void *dest, char val, int count) {
  char *temp = (char *)dest;
  for( ; count != 0; count--) *temp++ = val;
  return dest;
}

void *memsetw (void *dest, short val, int count) {
  short *temp = (short *)dest;
  for( ; count != 0; count--) *temp++ = val;
  return dest;
}
void scroll () {
    char *addr;
    for (int i = 0; i < 24; i++) {
      addr = (char*)(VIDEO + i*160);
      memcpy (addr, addr+160, 160);
    }
    unsigned short blank = 0x20 + (0x0f<<8);   // blank character (word)
    memsetw (addr+160, blank, 80);
    posy--;
}

void kputch (char c) {
  char *screen;
  
  if (c=='\n') {
    posy ++;
    if (posy >= 25) scroll ();
    posx = 0;
    uartputc ('\n');  // serielle Konsole
    return;
  }
  
  screen = (char*) (VIDEO + posy*160 + posx*2);
  *screen = c;
  posx++;
  if (posx == 80) { posy++; posx = 0; }
  if (posy >= 25) scroll ();

  // auf serielle Konsole schreiben; ohne Erkl�rung  
  if (c == 0x100) {  //  backspace
    uartputc('\b'); uartputc(' '); uartputc('\b');
  } else uartputc(c);
}
void clrscr () {
  posx = posy = 0;
  unsigned blank = 0x20 + (0x0f<<8);   // blank character (word)
  char *screen;
  if (paging_ready)
    screen = (char*) 0xb8000;
  else
    screen = (char*) 0xc0000000 + 0xb8000;
  memsetw (screen, blank, 80*25);
}
void *memcpy (void *dest, const void *src, int count) {
  const char *sp = (const char *)src;
  char *dp = (char *)dest;
  for (; count != 0; count--) 
    *dp++ = *sp++;
  return dest;
}

void *strncpy (void *dest, const void *src, int count) {
  // like memcpy, but copies only until first \0 character
  const char *sp = (const char *)src;
  char *dp = (char *)dest;
  for (; count != 0; count--) {
    *dp = *sp;
    if (*dp == 0) break;
    dp++; sp++;
  }
  return dest;
}
void hexdump (unsigned int start, unsigned int end) {
  char z;
  for (unsigned int i=start; i < end; i+=16) {
    printf ("%x  ", i);  // address
    // hex values
    for (int j=i; j<i+16; j++) {
      printf ("%02x ", (unsigned char)PEEK(j));
      if (j==i+7) kputch (' ');
    };
    kputch (' ');
    // char values
    for (int j=i; j<i+16; j++) {
      z = PEEK(j);
      if ((z>32)&&(z<127)) {
        kputch (PEEK(j));
      } else {
        kputch ('.');
      }
    }
    
    kputch ('\n');
  }
}
unsigned short inportw (unsigned short port) {
  unsigned short retval;
  asm volatile ("inw %%dx, %%ax" : "=a" (retval) : "d" (port));
  return retval;
}

void outportw (unsigned short port, unsigned short data) {
  asm volatile ("outw %%ax, %%dx" : : "d" (port), "a" (data));
}
void fill_idt_entry (unsigned char num, unsigned long address, 
    unsigned short gdtsel, unsigned char flags, unsigned char type) {
  if (num >= 0 && num < 256) {
    idt[num].addr_low  = address & 0xFFFF; // address is the handler address
    idt[num].addr_high = (address >> 16) & 0xFFFF;
    idt[num].gdtsel    = gdtsel;           // GDT sel.: user mode or kernel mode?
    idt[num].zeroes    = 0;
    idt[num].flags     = flags;
    idt[num].type      = type;
  }
}
static void set_irqmask (unsigned short mask) {
  outportb (IO_PIC_MASTER_DATA, (char)(mask % 256) );
  outportb (IO_PIC_SLAVE_DATA,  (char)(mask >> 8)  );
}

unsigned short get_irqmask () {
  return inportb (IO_PIC_MASTER_DATA) 
      + (inportb (IO_PIC_SLAVE_DATA) << 8);
}

static void enable_interrupt (int number) {
  set_irqmask ( 
    get_irqmask ()        // the current value
    & ~(1 << number)      // 16 one-bits, but bit "number" cleared
  );
}
void irq_handler (struct regs *r) {
  int number = r->int_no - 32;                      // interrupt number
  void (*handler)(struct regs *r);                  // type of handler functions

  if (number >= 8)  
    outportb (IO_PIC_SLAVE_CMD, END_OF_INTERRUPT);  // notify slave  PIC
  outportb (IO_PIC_MASTER_CMD, END_OF_INTERRUPT);   // notify master PIC

  handler = interrupt_handlers[number];
  if (handler != NULL)  handler (r);
}
void install_interrupt_handler (int irq, void (*handler)(struct regs *r)) {
  if (irq >= 0 && irq < 16)
    interrupt_handlers[irq] = handler;
}
void fault_handler (struct regs *r) {
  if (r->int_no >= 0 && r->int_no < 32) {
    printf ("'%s' (%d) Exception at 0x%08x.\n", 
      exception_messages[r->int_no], r->int_no, r->eip);        
    printf ("eflags: 0x%08x  errcode: 0x%08x\n", r->eflags, r->err_code);
    printf ("eax: %08x  ebx: %08x  ecx: %08x  edx: %08x \n",
      r->eax, r->ebx, r->ecx, r->edx);
    printf ("eip: %08x  esp: %08x  int: %8d  err: %8d \n", 
      r->eip, r->esp, r->int_no, r->err_code);
    printf ("ebp: %08x  cs: %d  ds: %d  es: %d  fs: %d  ss: %x \n",
      r->ebp, r->cs, r->ds, r->es, r->fs, r->ss);

    if (r->int_no == 14) {
      // page fault
      unsigned int faulting_address;
      asm volatile ("mov %%cr2, %0" : "=r" (faulting_address));
      printf ("faulting address (page fault): 0x%x, address space = %d\n",
        faulting_address, current_as);
        
      // The error code gives us details of what happened.
      int present   = !(r->err_code & 0x1); // Page not present
      int rw = r->err_code & 0x2;           // Write operation?
      int us = r->err_code & 0x4;           // Processor was in user-mode?
      int reserved = r->err_code & 0x8;     // Overwritten CPU-reserved bits of page entry?
      int id = r->err_code & 0x10;          // Caused by an instruction fetch?
      printf ("error code: ");

       if (present) {printf("present ");}
       if (rw) {printf("read-only ");}
       if (us) {printf("user-mode ");}
       if (reserved) {printf("reserved ");}
       if (id) {printf("instruction-fetch ");}
      printf ("\n");
    }
    printf ("System Stops\n");   
    asm ("cli; \n hlt;");
  }
}
void keyboard_handler (struct regs *r) {
  unsigned char s = inportb (0x60);
  char c;
  if (s < 128)
    c = scancode_table[s];
  else
    c = 0;
  
  if (c != 0 && pos < 256) {
    buffer[pos] = c;
    // printf ("VIDEO = 0x%x, posy = %d\n", VIDEO, posy);
    printf ("%c", c);
    pos++;
    unread++;
  }
  
  return;
};
void timer_handler (struct regs *r) {
  ticks++;
  /*
  if (ticks % 10 == 0) {
    if (posy == 25) clrscr ();
    printf ("T");
  }
  */
  return;
};
void kreadline (char *s, int len) {
  int read_chars = 0;
  for (;;) {
    if (pos>0 && buffer[pos-1]=='\n') {
      buffer[pos-1] = 0;  // String terminieren
      strncpy (s, buffer, len);
      pos = 0;
      return;
    }
  }   
}
void install_syscall_handler (int syscallno, void *syscall_handler) {
  if (syscallno < MAX_SYSCALLS) 
    syscall_table[syscallno] = syscall_handler;
  return;
};
void syscall_handler (struct regs *r) {
  void (*handler) (struct regs*);   // handler is a function pointer
  int number = r->eax;
  handler = syscall_table[number];
  if (handler != 0) {
    handler (r);
  } else {
    printf ("Unknown syscall no. eax=0x%x; ebx=0x%x. eip=0x%x, esp=0x%x. "
            "Continuing.\n", r->eax, r->ebx, r->eip, r->esp);
  };
  return;
}
void syscall_printf (struct regs *r) {
  // eax: syscall number, ebx: string address
  char *s = (char*) r->ebx;
  printf ("%s", s);
  return;
}
void syscall_kpeek (struct regs *r) {
  // eax: syscall number, ebx: memory address
  int page = r->ebx / 4096;
  if (pageno_to_frameno (page) == -1)   
    r->eax = -1;        
  else  
    r->eax = (unsigned char)*(char*)(r->ebx);
    // letzte Cast-Operation noetig, damit Werte ueber 128 nicht
    // als negative Werte interpretiert werden (signed char)
}

void syscall_kpoke (struct regs *r) {
  // eax: syscall number, ebx: memory address, ecx: value
  int page = r->ebx / 4096;
  if (pageno_to_frameno (page) != -1)   
    *(char*)(r->ebx) = r->ecx;
}
int syscall1 (int eax) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax) );
  return result ;
}

int syscall2 (int eax, int ebx) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax), "b" (ebx) );
  return result ;
}

int syscall3 (int eax, int ebx, int ecx) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax), "b" (ebx), "c" (ecx) );
  return result ;
}

int syscall4 (int eax, int ebx, int ecx, int edx) {
  int result;
  asm ( "int $0x80" : "=a" (result) 
                    : "a" (eax), "b" (ebx), "c" (ecx), "d" (edx) );
  return result ;
}
void userprint (char *s) {
  syscall2 (__NR_printf, (unsigned int)s);
}

int kpeek (unsigned int address) {
  return syscall2 (__NR_kpeek, address);
}

void kpoke (unsigned int address, unsigned char value) {
  syscall3 (__NR_kpoke, address, value);
}
int get_free_address_space () {
  addr_space_id id = 0;
  while ((address_spaces[id].status != AS_FREE) 
         && (id<MAX_ADDR_SPACES)) id++;
  if (id==MAX_ADDR_SPACES) id = -1;
  return id;
}
int create_new_address_space (int initial_ram, int initial_stack) {
  MAKE_MULTIPLE_OF_PAGESIZE (initial_ram);
  MAKE_MULTIPLE_OF_PAGESIZE (initial_stack);
  // reserve address space table entry
  addr_space_id id;
  if ( (id = get_free_address_space()) == -1 )  return -1;    // fail
  address_spaces[id].status    = AS_USED;
  address_spaces[id].memstart  = BINARY_LOAD_ADDRESS;
  address_spaces[id].memend    = BINARY_LOAD_ADDRESS + initial_ram;
  address_spaces[id].stacksize = initial_stack;
  address_spaces[id].refcount  = 1;  // default: used by one process
  page_directory *new_pd = (void*)request_new_page (0);
  if (new_pd == NULL) {  // Error
    printf ("\nERROR: no free page, aborting create_new_address_space\n");
    return -1;
  };
  memset (new_pd, 0, sizeof(page_directory));   // sets new_pd
  address_spaces[id].pd = new_pd;
  *new_pd = kernel_pd;
  new_pd->ptds[0].user_accessible = true;  // Hier ist noch ein Bug,
                                           // die Zeile sollte weg...

  int frameno, pageno;  // used in the following two code chunks
  if (initial_ram > 0)   {  pageno = 0;
                            while (initial_ram > 0) {
                              if ((frameno = request_new_frame ()) < 0) {
                                printf ("\nERROR: no free frame, aborting create_new_address_space\n");
                                return -1;
                              };
                              as_map_page_to_frame (id, pageno, frameno);
                              pageno++;
                              initial_ram -= PAGE_SIZE;
                            };  }
  if (initial_stack > 0) {  pageno = TOP_OF_USER_MODE_STACK / PAGE_SIZE;
                            while (initial_stack > 0) {
                              if ((frameno = request_new_frame ()) < 0) {
                                printf ("\nERROR: no free frame, aborting create_new_address_space\n");
                                return -1;
                              };
                              pageno--;
                              as_map_page_to_frame (id, pageno, frameno);
                              initial_stack -= PAGE_SIZE;
                            }     }
  return id;
};
int as_map_page_to_frame (int as, unsigned int pageno, unsigned int frameno) {
  // for address space as, map page #pageno to frame #frameno
  page_table* pt;
  page_directory* pd;

  pd = address_spaces[as].pd;           // use the right address space
  unsigned int pdindex = pageno/1024;   // calculuate pd entry
  unsigned int ptindex = pageno%1024;   // ... and pt entry

  if ( ! pd->ptds[pdindex].present) {
    // page table is not present
      int new_frame_id = request_new_frame ();
      unsigned int address = PHYSICAL (new_frame_id << 12);
      pt = (page_table *) address;
      printf (">>");
      memset (pt, 0, sizeof(page_table));
      printf ("<<");
      UMAPD ( &(pd->ptds[pdindex]), new_frame_id << 12);  // sets pt
  } else {
    // get the page table
    pt = (page_table*) PHYSICAL(pd->ptds[pdindex].frame_addr << 12);
  };
  if (pdindex < 704)   // address below 0xb0000000 -> user access
    UMAP ( &(pt->pds[ptindex]), frameno << 12 );   // user
  else
    KMAP ( &(pt->pds[ptindex]), frameno << 12 );   // kernel
  return 0;
};
void activate_address_space (addr_space_id id) {
  // NOTE: Do not call this from the scheduler; where needed, replicate the code
  unsigned int virt = (unsigned int)address_spaces[id].pd;  // get PD address
  unsigned int phys = mmu (0, virt);            // and find its physical address
  asm volatile ("mov %0, %%cr3" : : "r"(phys)); // write CR3 register
  current_as = id;                              // set current address space
  current_pd = address_spaces[id].pd;           // set current page directory
  return;
};
unsigned int mmu_p (addr_space_id id, unsigned int pageno) {
  unsigned int pdindex, ptindex;
  page_directory *pd;
  page_table     *pt;
  pdindex = pageno/1024;
  ptindex = pageno%1024;
  pd = address_spaces[id].pd;
  if ( ! pd->ptds[pdindex].present ) {
    return -1;
  } else {
    pt = (page_table*) PHYSICAL(pd->ptds[pdindex].frame_addr << 12);
    if ( pt->pds[ptindex].present ) {
      return pt->pds[ptindex].frame_addr;
    } else {
      return -1;
    };
  }
}

unsigned int mmu (addr_space_id id, unsigned int vaddress) {
  unsigned int tmp = mmu_p (id, (vaddress >> 12));
  if (tmp == -1)
    return -1;  // fail
  else
    return (tmp << 12) + (vaddress % PAGE_SIZE);
}
int register_new_tcb (addr_space_id as_id) {
  // called by ulix_fork() which aquires LOCK (thread_list_lock)
  boolean tcbfound = false;
  int tcbid;
  for ( tcbid=next_pid; ((tcbid<MAX_THREADS) 
                         && (!tcbfound));     tcbid++ ) {
    if (thread_table[tcbid].used == false) {
      tcbfound = true;
      break;
    }
  };
  if (!tcbfound) {                                  // continue searching at 1
    for ( tcbid=1; ((tcbid<next_pid) && (!tcbfound)); tcbid++ ) {
      if (thread_table[tcbid].used == false) {
        tcbfound = true;
        break;
      }
    };
  };

  if (tcbfound) next_pid = tcbid+1;                 // update next_pid:
  // either tcbfound == false or tcbid == index of first free TCB
  if (!tcbfound) {
    return -1; // no free TCB!
  };
  thread_table[tcbid].used       = true;   // mark as used
  thread_table[tcbid].addr_space = as_id;  // enter address space ID
  return tcbid;
}  
void start_program_from_ram (unsigned int address, int size) {
  addr_space_id as;
  thread_id tid;
  

      /// HIER LOESUNG EINTRAGEN


  

      /// HIER LOESUNG EINTRAGEN


    unsigned int framenos[KERNEL_STACK_PAGES];   
      // frame numbers of kernel stack pages
    int i; for (i=0; i<KERNEL_STACK_PAGES; i++)
      framenos[i] = request_new_frame();
    /*
    page_table* stackpgtable = (page_table*)request_new_page(0);
    memset (stackpgtable, 0, sizeof(page_table));
    KMAPD ( &current_pd->ptds[767], mmu (0, (unsigned int)stackpgtable) );
    */
    for (i=0; i<KERNEL_STACK_PAGES; i++) {
      as_map_page_to_frame (current_as, 0xbffff - i, framenos[i]);
    }
    char* kstack = (char*) (TOP_OF_KERNEL_MODE_STACK-KERNEL_STACK_SIZE);
    unsigned int adr = (unsigned int)kstack;  // one page for kernel stack

    tss_entry.esp0 = adr+KERNEL_STACK_SIZE;
    
    thread_table[tid].esp0 = (unsigned int)kstack + KERNEL_STACK_SIZE;
    thread_table[tid].ebp  = (unsigned int)kstack + KERNEL_STACK_SIZE;

  current_task = tid;                      // make this the current task  
  cpu_usermode (BINARY_LOAD_ADDRESS, 
                TOP_OF_USER_MODE_STACK);   // jump to user mode
};
static void write_tss (int num, unsigned short ss0, unsigned int esp0) {
   unsigned int base = (unsigned int) &tss_entry;
   unsigned int limit = sizeof (tss_entry) - 1;
   fill_gdt_entry (num, base, limit, 0xE9, 0x00);   // enter it in GDT

   memset (&tss_entry, 0, sizeof(tss_entry));       // fill with zeros

   tss_entry.ss0  = ss0;  // Set the kernel stack segment.
   tss_entry.esp0 = esp0; // Set the kernel stack pointer.
} 
int main () {
  posx = 0; posy = 8;  // set cursor
  printf ("[1] entering main()\n");

  for (int i=1; i<1024; i++) {
    fill_page_table_desc (&(current_pd->ptds[i]), false, false, false, 0);
  };
  KMAPD ( &(current_pd->ptds[  0]), (unsigned int)(current_pt)-0xC0000000 );
  KMAPD ( &(current_pd->ptds[768]), (unsigned int)(current_pt)-0xC0000000 );
  for (int i=0; i<1023; i++) {
    KMAP ( &(current_pt->pds[i]), i*4096 );
  };
  printf ("[2] page directory setup, with identity mapping\n");
  unsigned int cr0;
  char *kernel_pd_address;
  kernel_pd_address = (char*)(current_pd) - 0xC0000000;
  asm volatile ("mov %0, %%cr3" : : "r"(kernel_pd_address)); 
    // write CR3
  asm volatile ("mov %%cr0, %0" : "=r"(cr0) : );  // read  CR0
  cr0 |= (1<<31);      // Enable paging by setting PG bit 31 of CR0
  asm volatile ("mov %0, %%cr0" : : "r"(cr0) );   // write CR0
  printf ("[3] paging activated.\n");
  address_spaces[0].status   = AS_USED;
  address_spaces[0].pd       = &kernel_pd;
  address_spaces[0].pid      = -1;         // not a process
  gdt_install ();  // replace "trick GDT" with regular GDT

  paging_ready = true;
  printf ("[4] regular GDT is active\n");
  VIDEO = 0xb8000;  // Segmentierung nicht mehr noetig

  
  memset (kernel_pt_ram, 0, 4);

  for (unsigned int fid=0; fid<NUMBER_OF_FRAMES; fid++) {
    KMAP ( &(kernel_pt_ram[fid/1024].pds[fid%1024]), fid*PAGE_SIZE );
  }
  unsigned int physaddr;
  for (int i=0; i<16; i++) {
    // get physical address of kernel_pt_ram[i]
    physaddr = (unsigned int)(&(kernel_pt_ram[i])) - 0xc0000000;
    KMAPD ( &(current_pd->ptds[832+i]), physaddr );
  };

  gdt_flush ();
  VIDEO = PHYSICAL (0xb8000);

    memset (ftable, 0, NUMBER_OF_FRAMES/8);  // all frames are free
    memset (ftable, 0xff, 128);
    free_frames -= 1024;
  idtp.limit = (sizeof (struct idt_entry) * 256) - 1;   // must do -1
  idtp.base  = (int) &idt;
  idt_load ();
  FILL_IDT( 0); FILL_IDT( 1); FILL_IDT( 2); FILL_IDT( 3); FILL_IDT( 4); 
  FILL_IDT( 5); FILL_IDT( 6); FILL_IDT( 7); FILL_IDT( 8); FILL_IDT( 9);
  FILL_IDT(10); FILL_IDT(11); FILL_IDT(12); FILL_IDT(13); FILL_IDT(14); 
  FILL_IDT(15); FILL_IDT(16); FILL_IDT(17); FILL_IDT(18); FILL_IDT(19);
  FILL_IDT(20); FILL_IDT(21); FILL_IDT(22); FILL_IDT(23); FILL_IDT(24);
  FILL_IDT(25); FILL_IDT(26); FILL_IDT(27); FILL_IDT(28); FILL_IDT(29);
  FILL_IDT(30); FILL_IDT(31); FILL_IDT(128);
  outportb (IO_PIC_MASTER_CMD,  0x11);  // ICW1: initialize; begin programming
  outportb (IO_PIC_SLAVE_CMD,   0x11);  // ICW1: dito, for PIC2
  outportb (IO_PIC_MASTER_DATA, 0x20);  // ICW2 for PIC1: offset 0x20 
                                        // (remaps 0x00..0x07 -> 0x20..0x27)
  outportb (IO_PIC_SLAVE_DATA,  0x28);  // ICW2 for PIC2: offset 0x28 
                                        // (remaps 0x08..0x0f -> 0x28..0x2f)
  outportb (IO_PIC_MASTER_DATA, 0x04);  // ICW3 for PIC1: there's a slave on IRQ 2 
                                        // (0b00000100 = 0x04)
  outportb (IO_PIC_SLAVE_DATA,  0x02);  // ICW3 for PIC2: your slave ID is 2
  outportb (IO_PIC_MASTER_DATA, 0x01);  // ICW4 for PIC1 and PIC2: 8086 mode
  outportb (IO_PIC_SLAVE_DATA,  0x01);
  outportb (IO_PIC_MASTER_DATA, 0x00);  // PIC1: mask 0
  outportb (IO_PIC_SLAVE_DATA,  0x00);  // PIC2: mask 0
  set_irqmask (0xFFFF);           // initialize IRQ mask
  enable_interrupt (IRQ_SLAVE);   // IRQ slave

  // flags: 1 (present), 11 (DPL 3), 0; type: 1110 (32 bit interrupt gate)
  fill_idt_entry (32, (unsigned int)irq0,  0x08, 0b1110, 0b1110);
  fill_idt_entry (33, (unsigned int)irq1,  0x08, 0b1110, 0b1110);
  fill_idt_entry (34, (unsigned int)irq2,  0x08, 0b1110, 0b1110);
  fill_idt_entry (35, (unsigned int)irq3,  0x08, 0b1110, 0b1110);
  fill_idt_entry (36, (unsigned int)irq4,  0x08, 0b1110, 0b1110);
  fill_idt_entry (37, (unsigned int)irq5,  0x08, 0b1110, 0b1110);
  fill_idt_entry (38, (unsigned int)irq6,  0x08, 0b1110, 0b1110);
  fill_idt_entry (39, (unsigned int)irq7,  0x08, 0b1110, 0b1110);
  fill_idt_entry (40, (unsigned int)irq8,  0x08, 0b1110, 0b1110);
  fill_idt_entry (41, (unsigned int)irq9,  0x08, 0b1110, 0b1110);
  fill_idt_entry (42, (unsigned int)irq10, 0x08, 0b1110, 0b1110);
  fill_idt_entry (43, (unsigned int)irq11, 0x08, 0b1110, 0b1110);
  fill_idt_entry (44, (unsigned int)irq12, 0x08, 0b1110, 0b1110);
  fill_idt_entry (45, (unsigned int)irq13, 0x08, 0b1110, 0b1110);
  fill_idt_entry (46, (unsigned int)irq14, 0x08, 0b1110, 0b1110);
  fill_idt_entry (47, (unsigned int)irq15, 0x08, 0b1110, 0b1110);
  install_interrupt_handler (IRQ_KBD, keyboard_handler);
  enable_interrupt (IRQ_KBD);
  // install_interrupt_handler (IRQ_TIMER, timer_handler);
  // enable_interrupt (IRQ_TIMER);
  printf ("ENABLE INTERRUPTS\n");
  asm ("sti");
  /*
  printf ("TEST req_frame: free_frames = %d, ", free_frames);
  int fid = request_new_frame ();
  printf ("frameid = 0x%x, free_frames = %d\n", fid, free_frames);

  printf ("TEST req_page:  free_frames = %d, ", free_frames);
  unsigned int *address = request_new_page (0);
  printf ("addr = 0x%x, free_frames = %d\n", address, free_frames);
    
  // Use new page for a string
  memset (address, 'z', PAGE_SIZE);
  char *string = (char *)address; string[10] = 0;
  printf ("Test-String of 10 'z's: %s  -- address: 0x%x\n", 
    string, (unsigned int)string);
  printf ("pageno_to_frameno (0x%x) = 0x%x\n", 
    (unsigned int)address >> 12, 
    pageno_to_frameno ((unsigned int)address >> 12));
    
  release_page ((unsigned int)address >> 12);
  printf ("After release_page (0x%x): free_frames = %d\n", 
    (unsigned int)address >> 12, free_frames);
  printf ("pageno_to_frameno (0x%x) = %d  (-1: not mapped)\n", 
    (unsigned int)address >> 12, 
    pageno_to_frameno ((unsigned int)address >> 12));
  */
  install_syscall_handler (__NR_printf, syscall_printf);
  install_syscall_handler (__NR_kpeek,  syscall_kpeek);
  install_syscall_handler (__NR_kpoke,  syscall_kpoke);
  printf ("Hallo Welt\n");

  // Jetzt auf User Mode umschalten
  printf ("Entering User Mode...\n");

  // ...
  for (;;);   // inifinite loop
}
