#define false 0
#define true 1
#define MEM_SIZE 1024*1024*64        // 64 MByte
#define MAX_ADDRESS MEM_SIZE-1       // last valid physical address
#define PAGE_SIZE 4096               // Intel: 4K pages
#define NUMBER_OF_FRAMES MEM_SIZE/PAGE_SIZE
#define asm __asm__
#define volatile __volatile__
#define NULL ((void*) 0)
struct gdt_entry {
  unsigned int limit_low   : 16;
  unsigned int base_low    : 16;
  unsigned int base_middle :  8;
  unsigned int access      :  8;
  unsigned int flags       :  4;
  unsigned int limit_high  :  4;
  unsigned int base_high   :  8;
};

struct gdt_ptr {
  unsigned int limit       : 16;
  unsigned int base        : 32;
} __attribute__((packed));
typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int undocumented   :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_table_desc;

typedef struct { page_table_desc ptds[1024]; } page_directory;
typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int dirty          :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_desc;

typedef struct { page_desc pds[1024]; } page_table;
typedef unsigned int boolean;
struct gdt_entry gdt[6];
struct gdt_ptr gp;
page_directory kernel_pd     __attribute__ ((aligned (4096)));
page_table kernel_pt         __attribute__ ((aligned (4096)));
page_table kernel_pt_ram[16] __attribute__ ((aligned (4096)));

page_directory* current_pd = &kernel_pd;
page_table*     current_pt = &kernel_pt;
unsigned int free_frames = NUMBER_OF_FRAMES;
char place_for_ftable[NUMBER_OF_FRAMES/8];
unsigned int* ftable = (unsigned int*)(&place_for_ftable);
int paging_ready = false;
int posx, posy;
#define KMAP(pd,frame) \
  fill_page_desc (pd, true, true, false, false, frame)
#define KMAPD(ptd, frame) \
  fill_page_table_desc (ptd, true, true, false, frame)
#define INDEX_FROM_BIT(b) (b/32)   // 32 bits in an unsigned int
#define OFFSET_FROM_BIT(b) (b%32)
#define PHYSICAL(x) ((x)+0xd0000000)
#define PEEK(addr) (*(unsigned char *)(addr))
extern void gdt_flush();
void gdt_set_gate (int num, unsigned long base, 
  unsigned long limit, unsigned char access, unsigned char gran);
void gdt_install ();
page_table_desc* fill_page_table_desc (page_table_desc *ptd, 
  unsigned int present, unsigned int writeable, 
  unsigned int user_accessible, unsigned int frame_addr);
page_desc* fill_page_desc (page_desc *pd, unsigned int present,
  unsigned int writeable, unsigned int user_accessible,
  unsigned int dirty, unsigned int frame_addr);
static void set_frame (unsigned int frame_addr);
static void clear_frame (unsigned int frame_addr);
static unsigned int test_frame (unsigned int frame_addr);
int request_new_frame ();
void release_frame (unsigned int frameaddr);
unsigned int pageno_to_frameno (unsigned int pageno);
unsigned int* request_new_page (int need_more_pages);
void release_page (unsigned int pageno);
void *memset (void *dest, char val, int count);
extern int printf(const char *format, ...);
void kputch (char c);
extern void uartputc (int c);
void clrscr ();
void hexdump (unsigned int start, unsigned int end);
void gdt_set_gate(int num, unsigned long base, unsigned long limit,
                  unsigned char access, unsigned char gran) {
  /* Setup the descriptor base address */
  gdt[num].base_low = (base & 0xFFFF);            // 16 bits
  gdt[num].base_middle = (base >> 16) & 0xFF;     //  8 bits
  gdt[num].base_high = (base >> 24) & 0xFF;       //  8 bits

  /* Setup the descriptor limits */
  gdt[num].limit_low  = (limit & 0xFFFF);         // 16 bits
  gdt[num].limit_high = ((limit >> 16) & 0x0F);   //  4 bits

  /* Finally, set up the granularity and access flags */
  gdt[num].flags = gran & 0xF;
  gdt[num].access = access;
}

void gdt_install() {
  gp.limit = (sizeof(struct gdt_entry) * 6) - 1;
  gp.base = (int) &gdt;

  gdt_set_gate(0, 0, 0, 0, 0);    // NULL descriptor

  // code segment
  gdt_set_gate(1, 0, 0xFFFFFFFF, 0b10011010, 0b1100 /* 0xCF */);

  // data segment
  gdt_set_gate(2, 0, 0xFFFFFFFF, 0b10010010, 0b1100 /* 0xCF */);

  gdt_flush();
}
page_desc* fill_page_desc (page_desc *pd, unsigned int present,
  unsigned int writeable, unsigned int user_accessible,
  unsigned int dirty, unsigned int frame_addr) {

  memset (pd, 0, sizeof(pd));
  
  pd->present = present;
  pd->writeable = writeable;
  pd->user_accessible = user_accessible;
  pd->dirty = dirty;
  pd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
  return pd;
};

page_table_desc* fill_page_table_desc (page_table_desc *ptd, 
  unsigned int present, unsigned int writeable, 
  unsigned int user_accessible, unsigned int frame_addr) {

  memset (ptd, 0, sizeof(ptd));
  
  ptd->present = present;
  ptd->writeable = writeable;
  ptd->user_accessible = user_accessible;
  ptd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
  return ptd;
};
static void set_frame (unsigned int frame_addr) {
  unsigned int frame = frame_addr / PAGE_SIZE;
  unsigned int index  = INDEX_FROM_BIT  (frame);
  unsigned int offset = OFFSET_FROM_BIT (frame);
  ftable[index] |= (1 << offset);
}

static void clear_frame (unsigned int frame_addr) {
  unsigned int frame = frame_addr / PAGE_SIZE;
  unsigned int index  = INDEX_FROM_BIT  (frame);
  unsigned int offset = OFFSET_FROM_BIT (frame);
  ftable[index] &= ~(1 << offset);
}

static unsigned int test_frame (unsigned int frame_addr) {
  // returns true if frame is in use (false if frame is free)
  unsigned int frame = frame_addr / PAGE_SIZE;
  unsigned int index  = INDEX_FROM_BIT  (frame);
  unsigned int offset = OFFSET_FROM_BIT (frame);
  return ((ftable[index] & (1 << offset)) >> offset);
}
int request_new_frame () {
  unsigned int frameid;
  boolean found=false;
  for (frameid = 0; frameid < NUMBER_OF_FRAMES; frameid++) {
    if ( !test_frame (frameid*4096) ) {
      found=true;
      break;   // frame found
    };
  }
  if (found) {
    memset ((void*)PHYSICAL(frameid << 12), 0, PAGE_SIZE);
    set_frame (frameid*4096);
    free_frames--;
    return frameid;
  } else {
    return -1;
  }
};

void release_frame (unsigned int frameaddr) {
  if ( test_frame (frameaddr) ) {
    // only do work if frame is marked as used
    clear_frame (frameaddr);
    free_frames++;
  };
};
unsigned int pageno_to_frameno (unsigned int pageno) {
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  if ( ! current_pd->ptds[pdindex].present ) {
    return -1;       // we don't have that page table
  } else {
    // get the page table
    page_table* pt = (page_table*)
      ( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
    if ( pt->pds[ptindex].present ) {
      return pt->pds[ptindex].frame_addr;
    } else {
      return -1;     // we don't have that page
    };
  };    
};
unsigned int* request_new_page (int need_more_pages) {
  unsigned int newframeid = request_new_frame ();
  if (newframeid == -1) { return NULL; }  // exit if no frame was found
  unsigned int pageno = -1;
  for (unsigned int i=0xc0000; i<1024*1024; i++) {
    if ( pageno_to_frameno (i) == -1 ) {
      pageno = i;
      break;       // end loop, unmapped page was found
    };
  };

  if ( pageno == -1 ) {
    return NULL;   // we found no page -- whole 4 GB are mapped???
  };
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  page_table* pt;
  if (ptindex == 0) {
    // last entry! // create a new page table in the reserved frame
    page_table* pt = (page_table*) PHYSICAL(newframeid<<12);
    memset (pt, 0, PAGE_SIZE);
    KMAPD ( &(current_pd->ptds[pdindex]), newframeid << 12 );

    newframeid = request_new_frame ();  // get yet another frame
    if (newframeid == -1) {
      return NULL;                      // exit if no frame was found
      // note: we're not removing the new page table since we assume
      // it will be used soon anyway
    }
  };
  pt = (page_table*)( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
  // finally: enter the frame address
  KMAP ( &(pt->pds[ptindex]), newframeid * PAGE_SIZE );

  // invalidate cache entry
  asm volatile ("invlpg %0" : : "m"(*(char*)(pageno<<12)) );

  memset ((unsigned int*) (pageno*4096), 0, 4096);
  return ((unsigned int*) (pageno*4096));
}
void release_page (unsigned int pageno) {
  int frameno = pageno_to_frameno (pageno);  // we will need this later
  if ( frameno == -1 )  { return; }          // exit if no such page
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  page_table* pt;
  pt = (page_table*)
    ( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
  // write null page descriptor
  memset (&(pt->pds[ptindex]), 0, 4);
  fill_page_desc (&(pt->pds[ptindex]), false, false, false, false, 0);
  release_frame (frameno<<12);   // expects an address, not an ID
  asm volatile ("invlpg %0" : : "m"(*(char*)(pageno<<12)) );
  // gdt_flush ();
};
void *memset (void *dest, char val, int count) {
  char *temp = (char *)dest;
  for( ; count != 0; count--) *temp++ = val;
  return dest;
}
void kputch (char c) {
  char *screen;
  
  if (c=='\n') {
    posy ++;
    posx = 0;
    uartputc ('\n');
    return;
  }
  
  if (paging_ready)
    screen = (char*) 0xb8000 + posy*160 + posx*2;
  else
    screen = (char*) 0xc0000000 + 0xb8000 + posy*160 + posx*2;
  *screen = c;
  posx++;
  if (posx == 80) {
    posy++; posx = 0;
  }

  // auf serielle Konsole schreiben; ohne Erkl�rung  
  if (c == 0x100) {  //  backspace
    uartputc('\b'); uartputc(' '); uartputc('\b');
  } else uartputc(c);
}
void clrscr () {
  posx = posy = 0;
  int i;
  for ( i=0; i < 80*25; i++ ) kputch (' ');
  posx = posy = 0;
}
void hexdump (unsigned int start, unsigned int end) {
  char z;
  for (unsigned int i=start; i < end; i+=16) {
    printf ("%x  ", i);  // address
    // hex values
    for (int j=i; j<i+16; j++) {
      printf ("%02x ", (unsigned char)PEEK(j));
      if (j==i+7) kputch (' ');
    };
    kputch (' ');
    // char values
    for (int j=i; j<i+16; j++) {
      z = PEEK(j);
      if ((z>32)&&(z<127)) {
        kputch (PEEK(j));
      } else {
        kputch ('.');
      }
    }
    
    kputch ('\n');
  }
}
int main () {
  posx = 0; posy = 8;  // set cursor
  printf ("[1] entering main()\n");

  for (int i=1; i<1024; i++) {
    fill_page_table_desc (&(current_pd->ptds[i]), false, false, false, 0);
  };
  KMAPD ( &(current_pd->ptds[  0]), (unsigned int)(current_pt)-0xC0000000 );
  KMAPD ( &(current_pd->ptds[768]), (unsigned int)(current_pt)-0xC0000000 );
  for (int i=0; i<1023; i++) {
    KMAP ( &(current_pt->pds[i]), i*4096 );
  };
  printf ("[2] page directory setup, with identity mapping\n");
  unsigned int cr0;
  char *kernel_pd_address;
  kernel_pd_address = (char*)(current_pd) - 0xC0000000;
  asm volatile ("mov %0, %%cr3" : : "r"(kernel_pd_address)); 
    // write CR3
  asm volatile ("mov %%cr0, %0" : "=r"(cr0) : );  // read  CR0
  cr0 |= (1<<31);      // Enable paging by setting PG bit 31 of CR0
  asm volatile ("mov %0, %%cr0" : : "r"(cr0) );   // write CR0
  printf ("[3] paging activated.\n");
  gdt_install ();  // replace "trick GDT" with regular GDT

  paging_ready = true;
  printf ("[4] regular GDT is active\n");
  
  memset (kernel_pt_ram, 0, 4);

  for (unsigned int fid=0; fid<NUMBER_OF_FRAMES; fid++) {
    KMAP ( &(kernel_pt_ram[fid/1024].pds[fid%1024]), fid*PAGE_SIZE );
  }
  unsigned int physaddr;
  for (int i=0; i<16; i++) {
    // get physical address of kernel_pt_ram[i]
    physaddr = (unsigned int)(&(kernel_pt_ram[i])) - 0xc0000000;
    KMAPD ( &(current_pd->ptds[832+i]), physaddr );
  };

  gdt_flush ();
    memset (ftable, 0, NUMBER_OF_FRAMES/8);  // all frames are free
    memset (ftable, 0xff, 128);
    free_frames -= 1024;
  printf ("TEST req_frame: free_frames = %d, ", free_frames);
  int fid = request_new_frame ();
  printf ("frameid = 0x%x, free_frames = %d\n", fid, free_frames);

  printf ("TEST req_page:  free_frames = %d, ", free_frames);
  unsigned int *address = request_new_page (0);
  printf ("addr = 0x%x, free_frames = %d\n", address, free_frames);
    
  // Use new page for a string
  memset (address, 'z', PAGE_SIZE);
  char *string = (char *)address; string[10] = 0;
  printf ("Test-String of 10 'z's: %s  -- address: 0x%x\n", 
    string, (unsigned int)string);
  printf ("pageno_to_frameno (0x%x) = 0x%x\n", 
    (unsigned int)address >> 12, 
    pageno_to_frameno ((unsigned int)address >> 12));
    
  release_page ((unsigned int)address >> 12);
  printf ("After release_page (0x%x): free_frames = %d\n", 
    (unsigned int)address >> 12, free_frames);
  printf ("pageno_to_frameno (0x%x) = %d  (-1: not mapped)\n", 
    (unsigned int)address >> 12, 
    pageno_to_frameno ((unsigned int)address >> 12));

  // following line should make it hang
  // printf ("Test-String of 10 'z's: %s\n", string);
  for (;;);   // inifinite loop
}
