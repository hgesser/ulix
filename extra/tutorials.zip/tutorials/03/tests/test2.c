#include <stdio.h>

int main () {
  unsigned int frame_addr = 0xabcd1234;
  unsigned int tmpvalue = frame_addr & 0b11111111111111111111000000000000;
  printf ("frame_addr: %x\n", frame_addr);
  printf ("tmpvalue:   %x\n", tmpvalue);
}

