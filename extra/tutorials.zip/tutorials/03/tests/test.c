#include <stdio.h>

typedef unsigned int page_table_desc;	
typedef unsigned int page_desc;

typedef struct {
  page_desc pds[1024];
} page_table; // __attribute__ ((aligned (4096)));

typedef struct {
  page_table_desc ptds[1024];
} page_directory; // __attribute__ ((aligned (4096)));

page_directory pd;
page_table pt;

int main () {

  printf ("pt:     %x\n", (unsigned int) &pt);
  printf ("&pt[0]: %x\n", (unsigned int) &(pt.pds[0]));
  printf ("&pt[1]: %x\n", (unsigned int) &(pt.pds[1]));
}


