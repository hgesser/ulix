// This is not Ulix yet :)

#define false 0
#define true 1
#define asm __asm__
#define volatile __volatile__

typedef int size_t;

int paging_ready = false;


extern int printf(const char *format, ...);
extern void gdt_flush();

int posx, posy;

struct gdt_entry {
  unsigned int limit_low   : 16;
  unsigned int base_low    : 16;
  unsigned int base_middle :  8;
  unsigned int access      :  8;
  unsigned int flags       :  4;
  unsigned int limit_high  :  4;
  unsigned int base_high   :  8;
};

struct gdt_ptr {
  unsigned int limit       : 16;
  unsigned int base        : 32;
} __attribute__((packed));

struct gdt_entry gdt[6];
struct gdt_ptr gp;

typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int undocumented   :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_table_desc;

typedef struct {
   page_table_desc ptds[1024];
} page_directory;

typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int dirty          :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_desc;

typedef struct {
   page_desc pds[1024];
} page_table;


page_directory kernel_pd  __attribute__ ((aligned (4096)));
page_table kernel_pt      __attribute__ ((aligned (4096)));

page_directory* current_pd = &kernel_pd;
page_table*     current_pt = &kernel_pt;




//   FUNCTION IMPLEMENTATIONS

void *memset(void *dest, char val, size_t count) {
  char *temp = (char *)dest;
  for( ; count != 0; count--) *temp++ = val;
  return dest;
}


#define KMAP(pd,frame) fill_page_desc (pd, true, true, false, false, frame)
#define KMAPD(ptd, frame) fill_page_table_desc (ptd, true, true, false, frame)

page_desc* fill_page_desc (page_desc *pd, unsigned int present,
                           unsigned int writeable, unsigned int user_accessible,
                           unsigned int dirty, unsigned int frame_addr) {
  // /--> pd: pointer to page descriptor <--/ //

  // first fill the four bytes with zeros
  memset (pd, 0, sizeof(pd));
  
  // now enter the argument values in the right elements
  pd->present = present;
  pd->writeable = writeable;
  pd->user_accessible = user_accessible;
  pd->dirty = dirty;
  pd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
    /* Note: This assumes that the frame address is well-formed, i.e., *
     * it has zeroes in its lowest 12 bits                             */
  return pd;
};

page_table_desc* fill_page_table_desc (page_table_desc *ptd, unsigned int present,
                           unsigned int writeable, unsigned int user_accessible,
                           unsigned int frame_addr) {
  // /--> ptd: pointer to page table descriptor <--/ //
  
  // first fill the four bytes with zeros
  memset (ptd, 0, sizeof(ptd));
  
  // now enter the argument values in the right elements
  ptd->present = present;
  ptd->writeable = writeable;
  ptd->user_accessible = user_accessible;
  ptd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
  return ptd;
};



void gdt_set_gate(int num, unsigned long base, unsigned long limit,
                  unsigned char access, unsigned char gran) {
  /* Setup the descriptor base address */
  gdt[num].base_low = (base & 0xFFFF);            // 16 bits
  gdt[num].base_middle = (base >> 16) & 0xFF;     //  8 bits
  gdt[num].base_high = (base >> 24) & 0xFF;       //  8 bits

  /* Setup the descriptor limits */
  gdt[num].limit_low  = (limit & 0xFFFF);         // 16 bits
  gdt[num].limit_high = ((limit >> 16) & 0x0F);   //  4 bits

  /* Finally, set up the granularity and access flags */
  gdt[num].flags = gran & 0xF;
  gdt[num].access = access;
}


void gdt_install() {
  gp.limit = (sizeof(struct gdt_entry) * 6) - 1;
  gp.base = (int) &gdt;

  // NULL descriptor
  gdt_set_gate(0, 0, 0, 0, 0);

  // code segment
  gdt_set_gate(1, 0, 0xFFFFFFFF, 0b10011010, 0b1100 /* 0xCF */);

  // data segment
  gdt_set_gate(2, 0, 0xFFFFFFFF, 0b10010010, 0b1100 /* 0xCF */);

  gdt_flush();
}


void kputch (char c) {
  char *screen;
  
  if (c=='\n') {
    posy ++;
    posx = 0;
    return;
  }
  
  if (paging_ready)
    screen = (char*) 0xb8000 + posy*160 + posx*2;
  else
    screen = (char*) 0xc0000000 + 0xb8000 + posy*160 + posx*2;
  *screen = c;
  posx++;
  if (posx == 80) {
    posy++; posx = 0;
  }
}

void clrscr () {
  posx = posy = 0;
  int i;
  for ( i=0; i < 80*25; i++ ) kputch (' ');
  posx = posy = 0;
}

extern char start;
extern char stack_first_address;
extern char stack_last_address;

#define COPY_ESP_TO_VAR(x)  asm volatile ("mov %%esp, %0" : "=r"(x)          )

int main () {
  posx = 0; posy = 12;  // set cursor

  printf ("[1] entering main()\n");
  // paging
  for (int i=1; i<1024; i++) {
    // file page directory with null entries
    // Note: loop starts with i=1, not i=0
    fill_page_table_desc (&(current_pd->ptds[i]), false, false, false, 0);
  };
  
  // make page table kernel_pt first entry of page directory kernel_pd
  KMAPD ( &(current_pd->ptds[0]), (unsigned int)(current_pt)-0xC0000000 );

  // make page table kernel_pt also 768th entry of page directory kernel_pd
  KMAPD ( &(kernel_pd.ptds[768]), (unsigned int)(current_pt)-0xC0000000 );

  for (int i=0; i<1023; i++) {
    // map 1023 pages (4 MB minus 1 page)
    KMAP ( &(current_pt->pds[i]), i*4096 );
  };
  printf ("[2] page directory setup, with identity mapping\n");

  // load page directory, activate paging
  unsigned int cr0;
  char *kernel_pd_address;
  kernel_pd_address = (char*)(current_pd) - 0xC0000000;
  asm volatile ("mov %0, %%cr3" : : "r"(kernel_pd_address)); 
    // write CR3
  asm volatile ("mov %%cr0, %0" : "=r"(cr0) : );  // read  CR0
  cr0 |= (1<<31);      // Enable paging by setting PG bit 31 of CR0
  asm volatile ("mov %0, %%cr0" : : "r"(cr0) );   // write CR0
  printf ("[3] paging activated.\n");
  
  // replace "trick GDT" with regular GDT
  gdt_install();
  
  paging_ready = true;
  
  printf ("[4] regular GDT is active\n");

  // Hello World
  printf ("Hello World! This is not Ulix yet :) \n\n");
  printf ("address of main() [ulix.c]:    %08x\n", main);
  printf ("address of start  [start.asm]: %08x\n", &start);

  printf ("stack: %08x - %08x\n", &stack_first_address, &stack_last_address);

  for (;;);   // inifinite loop
}

