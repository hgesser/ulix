#line 327 "ulix.nw"
#define false 0
#define true 1
#line 418 "ulix.nw"
#define MEM_SIZE 1024*1024*64        // 64 MByte
#define MAX_ADDRESS MEM_SIZE-1       // last valid physical address
#define PAGE_SIZE 4096               // Intel: 4K pages
#define NUMBER_OF_FRAMES MEM_SIZE/PAGE_SIZE
#line 1068 "ulix.nw"
#define asm __asm__
#define volatile __volatile__
#define NULL ((void*) 0)
#line 1080 "ulix.nw"
#define IRQ_TIMER      0
#define IRQ_KBD        1
#define IRQ_SLAVE      2     // Here the slave PIC connects to master
#define IRQ_COM2       3
#define IRQ_COM1       4
#define IRQ_FDC        6
#define IRQ_IDE       14     // primary IDE controller; secondary has IRQ 15
#line 1116 "ulix.nw"
// I/O Addresses of the two programmable interrupt controllers
#define IO_PIC_MASTER_CMD   0x20  // Master (IRQs 0-7), command register
#define IO_PIC_MASTER_DATA  0x21  // Master, control register

#define IO_PIC_SLAVE_CMD    0xA0  // Slave (IRQs 8-15), command register
#define IO_PIC_SLAVE_DATA   0xA1  // Slave, control register
#line 1367 "ulix.nw"
#define END_OF_INTERRUPT  0x20
#line 1598 "ulix.nw"
#define KEY_UP     191
#define KEY_DOWN   192
#define KEY_LEFT   193
#define KEY_RIGHT  194
#line 1663 "ulix.nw"
#define MAX_SYSCALLS 0x8000         // max syscall number: 0x7fff
#line 1775 "ulix.nw"
#define __NR_printf   1
#define __NR_kpeek    0x7001
#define __NR_kpoke    0x7002
#line 1888 "ulix.nw"
#define MAX_ADDR_SPACES 1024
#line 1912 "ulix.nw"
#define BINARY_LOAD_ADDRESS      0x0
#define TOP_OF_USER_MODE_STACK   0xb0000000
#define TOP_OF_KERNEL_MODE_STACK 0xc0000000
#line 1935 "ulix.nw"
#define AS_FREE   0
#define AS_USED   1
#define AS_DELETE 2
#line 2235 "ulix.nw"
#define MAX_THREADS 1024
#line 2305 "ulix.nw"
#define PROGSIZE 32768
#line 2353 "ulix.nw"
#define KERNEL_STACK_PAGES 4
#define KERNEL_STACK_SIZE PAGE_SIZE * KERNEL_STACK_PAGES
#line 2536 "ulix.nw"
#define __NR_readline 2
#line 2568 "ulix.nw"
// Thread states
#define TSTATE_READY     1   // process is ready
#define TSTATE_FORK      3   // fork() has not completed
#define TSTATE_EXIT      4   // process has called exit()
#define TSTATE_WAITFOR   5   // process has called waitpid()
#define TSTATE_ZOMBIE    6   // wait for parent to retrieve exit value
#define TSTATE_WAITKEY   7   // wait for key press event
#define TSTATE_WAITFLP   8   // wait for floppy
#define TSTATE_LOCKED    9   // wait for lock
#define TSTATE_STOPPED  10   // stopped by SIGSTOP signal
#define TSTATE_WAITHD   11   // wait for hard disk
#line 2765 "ulix.nw"
#define __NR_fork 2
#line 2892 "ulix.nw"
#define IDE_CMD_READ  0x20
#define IDE_CMD_WRITE 0x30
#define IDE_CMD_IDENT 0xec     // identify disk
#define IDE_BSY       0x80     // 10000000  (bit 7)
#define IDE_DRDY      0x40     // 01000000  (bit 6)
#define IDE_DF        0x20     // 00100000  (bit 5)
#define IDE_ERR       0x01     // 00000001  (bit 0)
#line 2905 "ulix.nw"
// IDE output
#define IO_IDE_SEC_COUNT  0x1f2  // sector count register (read/write)
#define IO_IDE_SECTOR     0x1f3  // (32 bits in 0x1f3..0x1f6)
#define IO_IDE_DISKSEL    0x1f6  // disk select and upper 4 bits of sector no.
#define IO_IDE_COMMAND    0x1f7  // command register
#define IO_IDE_DEVCTRL    0x3f6  // device control register
// IDE input
#define IO_IDE_DATA       0x1f0  // data (read/write)
#define IO_IDE_STATUS     0x1f7  // status register (identical to command reg.)
#line 2988 "ulix.nw"
#define HD_OP_READ     0   // Controller liest gerade
#define HD_OP_WRITE    1   // Controller schreibt gerade
#define HD_OP_NONE    -1   // Controller ist idle
#define HD_SECSIZE   512   // Groesse eines Sektors
#line 1896 "ulix.nw"
typedef unsigned int addr_space_id;
#line 68 "ulix.nw"
struct gdt_entry {
  unsigned int limit_low   : 16;
  unsigned int base_low    : 16;
  unsigned int base_middle :  8;
  unsigned int access      :  8;
  unsigned int flags       :  4;
  unsigned int limit_high  :  4;
  unsigned int base_high   :  8;
};

struct gdt_ptr {
  unsigned int limit       : 16;
  unsigned int base        : 32;
} __attribute__((packed));
#line 181 "ulix.nw"
typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int undocumented   :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_table_desc;

typedef struct { page_table_desc ptds[1024]; } page_directory;
#line 204 "ulix.nw"
typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int dirty          :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_desc;

typedef struct { page_desc pds[1024]; } page_table;
#line 530 "ulix.nw"
typedef unsigned int boolean;
#line 1158 "ulix.nw"
struct idt_entry {
    unsigned int addr_low  : 16;   // lower 16 bits of address
    unsigned int gdtsel    : 16;   // use which GDT entry?
    unsigned int zeroes    :  8;   // must be set to 0
    unsigned int type      :  4;   // type of descriptor
    unsigned int flags     :  4;
    unsigned int addr_high : 16;   // higher 16 bits of address
} __attribute__((packed));
#line 1171 "ulix.nw"
struct idt_ptr {
    unsigned int limit   : 16;
    unsigned int base    : 32;
} __attribute__((packed));
#line 1284 "ulix.nw"
struct regs {
  unsigned int gs, fs, es, ds;
  unsigned int edi, esi, ebp, esp, ebx, edx, ecx, eax;
  unsigned int int_no, err_code;
  unsigned int eip, cs, eflags, useresp, ss;
};
#line 1922 "ulix.nw"
typedef struct {
  void         *pd;        // pointer to the page directory
  int          pid;        // process ID (if used by a process; -1 if not)
  short        status;     // are we using this address space?
  unsigned int memstart;   // first address below 0xc000.0000
  unsigned int memend;     // last  address below 0xc000.0000
  unsigned int stacksize;  // size of user mode stack
  unsigned int kstack_pt;  // stack page table (for kernel stack)
  unsigned int refcount;   // how many threads use this address space?
} address_space;
#line 2216 "ulix.nw"
typedef int thread_id;
typedef struct regs context_t;

typedef struct {
  thread_id     tid;         // thread id
  thread_id     ppid;        // parent process
  int           state;       // state of the process
  context_t     regs;        // context
  unsigned int  esp0;        // kernel stack pointer
  unsigned int  eip;         // program counter
  unsigned int  ebp;         // base pointer
  
#line 1903 "ulix.nw"
addr_space_id addr_space;  // memory usage
#line 2245 "ulix.nw"
boolean used;
#line 2660 "ulix.nw"
boolean new;
#line 2228 "ulix.nw"
} TCB;
#line 2402 "ulix.nw"
typedef struct {
  unsigned int prev_tss    : 32;  // unused: previous TSS
  unsigned int esp0, ss0   : 32;  // ESP and SS to load when we switch to ring 0
  long long u1, u2         : 64;  // unused: esp1, ss1, esp2, ss2 for rings 1 and 2
  unsigned int cr3         : 32;  // unused: page directory
  unsigned int eip, eflags : 32;
  unsigned int eax, ecx, edx, ebx, esp, ebp, esi, edi, es, cs, ss, ds, fs, gs : 32;
                                  // unused (dynamic, filled by CPU)
  long long u3             : 64;  // unused: ldt, trap, iomap
} __attribute__((packed)) tss_entry_struct;
#line 87 "ulix.nw"
struct gdt_entry gdt[6];
struct gdt_ptr gp;
#line 232 "ulix.nw"
page_directory kernel_pd     __attribute__ ((aligned (4096)));
page_table kernel_pt         __attribute__ ((aligned (4096)));
page_table kernel_pt_ram[16] __attribute__ ((aligned (4096)));

page_directory* current_pd = &kernel_pd;
page_table*     current_pt = &kernel_pt;
#line 407 "ulix.nw"
unsigned int free_frames = NUMBER_OF_FRAMES;
char place_for_ftable[NUMBER_OF_FRAMES/8];
unsigned int* ftable = (unsigned int*)(&place_for_ftable);
#line 735 "ulix.nw"
unsigned int VIDEO = 0xb8000 + 0xc0000000;
#line 776 "ulix.nw"
int paging_ready = false;
#line 988 "ulix.nw"
int posx, posy;
#line 1180 "ulix.nw"
struct idt_entry idt[256] = { 0 };
struct idt_ptr idtp;
#line 1370 "ulix.nw"
void *interrupt_handlers[16] = { 0 };
#line 1460 "ulix.nw"
char *exception_messages[] = {
  "Division By Zero",       "Debug",                        //  0,  1
  "Non Maskable Interrupt", "Breakpoint",                   //  2,  3
  "Into Detected Overflow", "Out of Bounds",                //  4,  5
  "Invalid Opcode",         "No Coprocessor",               //  6,  7
  "Double Fault",           "Coprocessor Segment Overrun",  //  8,  9
  "Bad TSS",                "Segment Not Present",          // 10, 11
  "Stack Fault",            "General Protection Fault",     // 12, 13
  "Page Fault",             "Unknown Interrupt",            // 14, 15
  "Coprocessor Fault",      "Alignment Check",              // 16, 17
  "Machine Check",                                          // 18
  "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
  "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
  "Reserved", "Reserved", "Reserved"                        // 19..31
};
#line 1605 "ulix.nw"
char scancode_table[128] = { 
  /*  0.. 9 */    0,  27, '1', '2', '3', '4', '5', '6', '7', '8',
  /* 10..19 */   '9', '0', '-', '=', '\b',       /* Backspace */
                 '\t', /* Tab */   'q', 'w', 'e', 'r',  
  /* 20..29 */   't', 'z', 'u', 'i', 'o', 'p', '[', ']', 
                 '\n', /* Enter */  0, /* Control */
  /* 30..39 */   'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',
  /* 40..49 */   '\'', '`', 0, /* Left shift */  '\\', 'y', 'x', 
                 'c', 'v', 'b', 'n',
  /* 50..59 */   'm', ',', '.', '/', 0, /* Right shift */
                 '*', 0, /* Alt */  ' ', /* Space bar */
                 0, /* CapsLock */  0, /* F1 */
  /* 60..69 */   0, 0, 0, 0, 0, 0, 0, 0, 0, /* F2..F10 */
                 0, /* NumLock */
  /* 70..79 */   0, /* Scroll Lock */   0, /* Home key */
                 KEY_UP, 0, /* Page Up */
                 '-', KEY_LEFT, 0, KEY_RIGHT,
                 '+', 0, /* End */
  /* 80..89 */   KEY_DOWN, 0, /* Page Down */
                 0, /* Insert Key */    0, /* Delete */
                 0, 0, 0, 0, /* F11 */  0, /* F12 */   0,
  /* 90..127     not defined */
};   // Scan Codes
short int pos = 0;                  // Puffer-Position
short int unread = 0;               // Anzahl "frischer" Zeichen
char buffer[256] = { 0 };           // Eingabe-Puffer
#line 1667 "ulix.nw"
void *syscall_table[MAX_SYSCALLS];
#line 1941 "ulix.nw"
address_space address_spaces[MAX_ADDR_SPACES] = { 0 };
#line 2135 "ulix.nw"
addr_space_id current_as = 0;  // global variable: current address space
#line 2239 "ulix.nw"
TCB thread_table[MAX_THREADS];
#line 2249 "ulix.nw"
int next_pid = 1;
#line 2301 "ulix.nw"
volatile int current_task;
#line 2415 "ulix.nw"
tss_entry_struct tss_entry;
#line 2505 "ulix.nw"
unsigned char usermodeprog[] = {
0x8D, 0x4C, 0x24, 0x04, 0x83, 0xE4, 0xF0, 0xFF,0x71, 0xFC, 0x55, 0x89, 0xE5, 0x51, 0x83, 0xEC,0x14, 0x83, 0xEC, 0x0C, 0x68, 0x03, 0x01, 0x00,0x00, 0xE8, 0xAB, 0x00, 0x00, 0x00, 0x83, 0xC4,0x10, 0xE8, 0xC3, 0x00, 0x00, 0x00, 0x89, 0x45,0xF4, 0x83, 0x7D, 0xF4, 0x00, 0x75, 0x12, 0x83,0xEC, 0x0C, 0x68, 0x17, 0x01, 0x00, 0x00, 0xE8,0x8D, 0x00, 0x00, 0x00, 0x83, 0xC4, 0x10, 0xEB,0xE8, 0x83, 0xEC, 0x0C, 0x68, 0x19, 0x01, 0x00,0x00, 0xE8, 0x7B, 0x00, 0x00, 0x00, 0x83, 0xC4,0x10, 0xEB, 0xD6, 0x83, 0xEC, 0x10, 0x8B, 0x44,0x24, 0x14, 0xCD, 0x80, 0x89, 0x44, 0x24, 0x0C,0x8B, 0x44, 0x24, 0x0C, 0x83, 0xC4, 0x10, 0xC3,0x53, 0x83, 0xEC, 0x10, 0x8B, 0x44, 0x24, 0x18,0x8B, 0x54, 0x24, 0x1C, 0x89, 0xD3, 0xCD, 0x80,0x89, 0x44, 0x24, 0x0C, 0x8B, 0x44, 0x24, 0x0C,0x83, 0xC4, 0x10, 0x5B, 0xC3, 0x53, 0x83, 0xEC,0x10, 0x8B, 0x44, 0x24, 0x18, 0x8B, 0x54, 0x24,0x1C, 0x8B, 0x4C, 0x24, 0x20, 0x89, 0xD3, 0xCD,0x80, 0x89, 0x44, 0x24, 0x0C, 0x8B, 0x44, 0x24,0x0C, 0x83, 0xC4, 0x10, 0x5B, 0xC3, 0x53, 0x83,0xEC, 0x10, 0x8B, 0x44, 0x24, 0x18, 0x8B, 0x5C,0x24, 0x1C, 0x8B, 0x4C, 0x24, 0x20, 0x8B, 0x54,0x24, 0x24, 0xCD, 0x80, 0x89, 0x44, 0x24, 0x0C,0x8B, 0x44, 0x24, 0x0C, 0x83, 0xC4, 0x10, 0x5B,0xC3, 0x8B, 0x44, 0x24, 0x04, 0x50, 0x6A, 0x01,0xE8, 0x93, 0xFF, 0xFF, 0xFF, 0x83, 0xC4, 0x08,0xC3, 0x8B, 0x44, 0x24, 0x04, 0x50, 0x6A, 0x02,0xE8, 0x83, 0xFF, 0xFF, 0xFF, 0x83, 0xC4, 0x08,0xC3, 0x53, 0x83, 0xEC, 0x10, 0xB8, 0x02, 0x00,0x00, 0x00, 0xCD, 0x80, 0x89, 0xDA, 0x89, 0x54,0x24, 0x0C, 0x8B, 0x44, 0x24, 0x0C, 0x83, 0xC4,0x10, 0x5B, 0xC3, 0x48, 0x61, 0x6C, 0x6C, 0x6F,0x20, 0x2D, 0x20, 0x55, 0x73, 0x65, 0x72, 0x20,0x4D, 0x6F, 0x64, 0x65, 0x21, 0x0A, 0x00, 0x53,0x00, 0x56, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};
#line 2791 "ulix.nw"
int scheduler_is_active = false;
#line 2803 "ulix.nw"
TCB *t_old; static TCB *t_new;
#line 2995 "ulix.nw"
char hd_buf[HD_SECSIZE];   // Puffer fuers Lesen/Schreiben
char hd_direction;
#line 313 "ulix.nw"
#define KMAP(pd,frame) \
  fill_page_desc (pd, true, true, false, false, frame)
#define KMAPD(ptd, frame) \
  fill_page_table_desc (ptd, true, true, false, frame)
#line 431 "ulix.nw"
#define INDEX_FROM_BIT(b) (b/32)   // 32 bits in an unsigned int
#define OFFSET_FROM_BIT(b) (b%32)
#line 581 "ulix.nw"
#define PHYSICAL(x) ((x)+0xd0000000)
#line 1061 "ulix.nw"
#define PEEK(addr) (*(unsigned char *)(addr))
#line 1432 "ulix.nw"
#define FILL_IDT(i) \
  fill_idt_entry (i, (unsigned int)isr##i, 0x08, 0b1110, 0b1110)
#line 1977 "ulix.nw"
#define MAKE_MULTIPLE_OF_PAGESIZE(x)  x = ((x+PAGE_SIZE-1)/PAGE_SIZE) \
  * PAGE_SIZE
#line 2117 "ulix.nw"
#define UMAP(pd,frame)    fill_page_desc (pd, true, true, true,  false, frame)
#define UMAPD(ptd, frame) fill_page_table_desc (ptd, true, true, true,  frame)
#line 2589 "ulix.nw"
#define phys_memcpy(target, source, size) \
  (unsigned int)memcpy ( (void*)PHYSICAL(target), (void*)PHYSICAL(source), size)
#define copy_frame(out, in)  phys_memcpy (out << 12, in << 12, PAGE_SIZE)
#line 2838 "ulix.nw"
#define COPY_VAR_TO_ESP(x)  asm volatile ("mov %0, %%esp" :         : "r"(x) )
#define COPY_VAR_TO_EBP(x)  asm volatile ("mov %0, %%ebp" :         : "r"(x) )
#define COPY_ESP_TO_VAR(x)  asm volatile ("mov %%esp, %0" : "=r"(x)          )
#define COPY_EBP_TO_VAR(x)  asm volatile ("mov %%ebp, %0" : "=r"(x)          )
#define WRITE_CR3(x)        asm volatile ("mov %0, %%cr3" :         : "r"(x) )
#line 98 "ulix.nw"
extern void gdt_flush();
#line 106 "ulix.nw"
void fill_gdt_entry (int num, unsigned long base, 
  unsigned long limit, unsigned char access, unsigned char gran);
#line 115 "ulix.nw"
void gdt_install ();
#line 256 "ulix.nw"
page_table_desc* fill_page_table_desc (page_table_desc *ptd, 
  unsigned int present, unsigned int writeable, 
  unsigned int user_accessible, unsigned int frame_addr);
#line 262 "ulix.nw"
page_desc* fill_page_desc (page_desc *pd, unsigned int present,
  unsigned int writeable, unsigned int user_accessible,
  unsigned int dirty, unsigned int frame_addr);
#line 442 "ulix.nw"
static void set_frame (unsigned int frame_addr);
static void clear_frame (unsigned int frame_addr);
static unsigned int test_frame (unsigned int frame_addr);
#line 482 "ulix.nw"
int request_new_frame ();
void release_frame (unsigned int frameaddr);
#line 550 "ulix.nw"
unsigned int pageno_to_frameno (unsigned int pageno);
#line 591 "ulix.nw"
unsigned int* request_new_page (int need_more_pages);
#line 692 "ulix.nw"
void release_page (unsigned int pageno);
#line 866 "ulix.nw"
void *memset  (void *dest, char val,  int count);
void *memsetw (void *dest, short val, int count);
#line 893 "ulix.nw"
extern int printf(const char *format, ...);
#line 906 "ulix.nw"
void kputch (char c);
#line 955 "ulix.nw"
extern void uartputc (int c);
#line 966 "ulix.nw"
void clrscr ();
#line 996 "ulix.nw"
void *memcpy (void *dest, const void *src, int count);
void *strncpy (void *dest, const void *src, int count);
#line 1028 "ulix.nw"
void hexdump (unsigned int start, unsigned int end);
#line 1092 "ulix.nw"
unsigned char  inportb (unsigned short port);
unsigned short inportw (unsigned short port);
void outportb (unsigned short port, unsigned char data);
void outportw (unsigned short port, unsigned short data);
#line 1188 "ulix.nw"
void fill_idt_entry (unsigned char num, unsigned long address, 
    unsigned short gdtsel, unsigned char flags, unsigned char type);
#line 1213 "ulix.nw"
extern void irq0(), irq1(), irq2(),  irq3(),  irq4(),  irq5(),  irq6(),  irq7();
extern void irq8(), irq9(), irq10(), irq11(), irq12(), irq13(), irq14(), irq15();
#line 1247 "ulix.nw"
static void set_irqmask (unsigned short mask);
static void enable_interrupt (int number);
unsigned short get_irqmask ();
#line 1377 "ulix.nw"
void install_interrupt_handler (int irq, void (*handler)(struct regs *r));
#line 1398 "ulix.nw"
extern void idt_load ();
#line 1421 "ulix.nw"
extern void isr0(),  isr1(),  isr2(),  isr3(),  isr4(),  isr5(),  
   isr6(),  isr7(),  isr8(),  isr9(),  isr10(), isr11(), isr12(), 
   isr13(), isr14(), isr15(), isr16(), isr17(), isr18(), isr19(), 
   isr20(), isr21(), isr22(), isr23(), isr24(), isr25(), isr26(), 
   isr27(), isr28(), isr29(), isr30(), isr31(), isr128();
#line 1479 "ulix.nw"
void fault_handler (struct regs *r);
#line 1554 "ulix.nw"
void keyboard_handler (struct regs *r);
#line 1638 "ulix.nw"
void kreadline (char *s, int len);
#line 1674 "ulix.nw"
void install_syscall_handler (int syscallno, void *syscall_handler);
#line 1785 "ulix.nw"
void syscall_printf (struct regs *r);
void syscall_kpeek (struct regs *r);
void syscall_kpoke (struct regs *r);
#line 2517 "ulix.nw"
// void syscall_.... (...);
#line 2521 "ulix.nw"
void syscall_readline (struct regs *r);
#line 2742 "ulix.nw"
void syscall_fork (context_t *r);
#line 1733 "ulix.nw"
int syscall1 (int eax);
int syscall2 (int eax, int ebx);
int syscall3 (int eax, int ebx, int ecx);
int syscall4 (int eax, int ebx, int ecx, int edx);
#line 1849 "ulix.nw"
void userprint (char *s);
int  kpeek (unsigned int address);
void kpoke (unsigned int address, unsigned char value);
#line 1947 "ulix.nw"
int get_free_address_space ();
#line 1969 "ulix.nw"
int create_new_address_space (int initial_ram, int initial_stack);
#line 2037 "ulix.nw"
int as_map_page_to_frame (int as, unsigned int pageno, unsigned int frameno);
#line 2143 "ulix.nw"
void activate_address_space (addr_space_id id);
#line 2168 "ulix.nw"
unsigned int mmu_p (addr_space_id id, unsigned int pageno);
unsigned int mmu (addr_space_id id, unsigned int vaddress);
#line 2281 "ulix.nw"
int register_new_tcb (addr_space_id as_id);
#line 2427 "ulix.nw"
static void write_tss (int num, unsigned short ss0, unsigned int esp0);
#line 2456 "ulix.nw"
extern void tss_flush();
#line 2463 "ulix.nw"
extern void cpu_usermode (unsigned int address, unsigned int stack);   
// assembler
#line 2582 "ulix.nw"
int u_fork (context_t *r, boolean create_thread, void *start_address);
#line 2704 "ulix.nw"
extern unsigned int get_eip ();
#line 2785 "ulix.nw"
void scheduler (context_t *r, int source);
#line 2952 "ulix.nw"
static inline void repeat_inportsl (int port, void *addr, int cnt);
static inline void repeat_outportsl (int port, void *addr, int cnt);
#line 2977 "ulix.nw"
void readsector_hd (int hd, int sector, char* buffer);
void writesector_hd (int hd, int sector, char* buffer);
#line 3043 "ulix.nw"
static int idewait (int checkerr);
#line 124 "ulix.nw"
void fill_gdt_entry(int num, unsigned long base, unsigned long limit,
                  unsigned char access, unsigned char gran) {
  /* Setup the descriptor base address */
  gdt[num].base_low = (base & 0xFFFF);            // 16 bits
  gdt[num].base_middle = (base >> 16) & 0xFF;     //  8 bits
  gdt[num].base_high = (base >> 24) & 0xFF;       //  8 bits

  /* Setup the descriptor limits */
  gdt[num].limit_low  = (limit & 0xFFFF);         // 16 bits
  gdt[num].limit_high = ((limit >> 16) & 0x0F);   //  4 bits

  /* Finally, set up the granularity and access flags */
  gdt[num].flags = gran & 0xF;
  gdt[num].access = access;
}

void gdt_install() {
  gp.limit = (sizeof(struct gdt_entry) * 6) - 1;
  gp.base = (int) &gdt;

  fill_gdt_entry(0, 0, 0, 0, 0);    // NULL descriptor

  // code segment
  fill_gdt_entry(1, 0, 0xFFFFFFFF, 0b10011010, 0b1100 /* 0xCF */);

  // data segment
  fill_gdt_entry(2, 0, 0xFFFFFFFF, 0b10010010, 0b1100 /* 0xCF */);

  
#line 2395 "ulix.nw"
fill_gdt_entry (3, 0, 0xFFFFFFFF, 0xFA, 0b1100);
fill_gdt_entry (4, 0, 0xFFFFFFFF, 0xF2, 0b1100);
#line 2421 "ulix.nw"
write_tss (5, 0x10, 0xC0000000);
#line 152 "ulix.nw"
                                  // spaeter!
  gdt_flush();
  tss_flush();
}
#line 278 "ulix.nw"
page_desc* fill_page_desc (page_desc *pd, unsigned int present,
  unsigned int writeable, unsigned int user_accessible,
  unsigned int dirty, unsigned int frame_addr) {

  memset (pd, 0, sizeof(pd));
  
  pd->present = present;
  pd->writeable = writeable;
  pd->user_accessible = user_accessible;
  pd->dirty = dirty;
  pd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
  return pd;
};

page_table_desc* fill_page_table_desc (page_table_desc *ptd, 
  unsigned int present, unsigned int writeable, 
  unsigned int user_accessible, unsigned int frame_addr) {

  memset (ptd, 0, sizeof(ptd));
  
  ptd->present = present;
  ptd->writeable = writeable;
  ptd->user_accessible = user_accessible;
  ptd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
  return ptd;
};
#line 459 "ulix.nw"
static void set_frame (unsigned int frame_addr) {
  
#line 452 "ulix.nw"
unsigned int frame = frame_addr / PAGE_SIZE;
unsigned int index  = INDEX_FROM_BIT  (frame);
unsigned int offset = OFFSET_FROM_BIT (frame);
#line 461 "ulix.nw"
  ftable[index] |= (1 << offset);
}

static void clear_frame (unsigned int frame_addr) {
  
#line 452 "ulix.nw"
unsigned int frame = frame_addr / PAGE_SIZE;
unsigned int index  = INDEX_FROM_BIT  (frame);
unsigned int offset = OFFSET_FROM_BIT (frame);
#line 466 "ulix.nw"
  ftable[index] &= ~(1 << offset);
}

static unsigned int test_frame (unsigned int frame_addr) {
  // returns true if frame is in use (false if frame is free)
  
#line 452 "ulix.nw"
unsigned int frame = frame_addr / PAGE_SIZE;
unsigned int index  = INDEX_FROM_BIT  (frame);
unsigned int offset = OFFSET_FROM_BIT (frame);
#line 472 "ulix.nw"
  return ((ftable[index] & (1 << offset)) >> offset);
}
#line 499 "ulix.nw"
int request_new_frame () {
  unsigned int frameid;
  boolean found=false;
  for (frameid = 0; frameid < NUMBER_OF_FRAMES; frameid++) {
    if ( !test_frame (frameid*4096) ) {
      found=true;
      break;   // frame found
    };
  }
  if (found) {
    memset ((void*)PHYSICAL(frameid << 12), 0, PAGE_SIZE);
    set_frame (frameid*4096);
    free_frames--;
    return frameid;
  } else {
    return -1;
  }
};

void release_frame (unsigned int frameaddr) {
  if ( test_frame (frameaddr) ) {
    // only do work if frame is marked as used
    clear_frame (frameaddr);
    free_frames++;
  };
};
#line 557 "ulix.nw"
unsigned int pageno_to_frameno (unsigned int pageno) {
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  if ( ! current_pd->ptds[pdindex].present ) {
    return -1;       // we don't have that page table
  } else {
    // get the page table
    page_table* pt = (page_table*)
      ( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
    if ( pt->pds[ptindex].present ) {
      return pt->pds[ptindex].frame_addr;
    } else {
      return -1;     // we don't have that page
    };
  };    
};
#line 601 "ulix.nw"
unsigned int* request_new_page (int need_more_pages) {
  
#line 607 "ulix.nw"
unsigned int newframeid = request_new_frame ();
if (newframeid == -1) { return NULL; }  // exit if no frame was found
unsigned int pageno = -1;
for (unsigned int i=0xc0000; i<1024*1024; i++) {
  if ( pageno_to_frameno (i) == -1 ) {
    pageno = i;
    break;       // end loop, unmapped page was found
  };
};

if ( pageno == -1 ) {
  return NULL;   // we found no page -- whole 4 GB are mapped???
};
#line 626 "ulix.nw"
unsigned int pdindex = pageno/1024;
unsigned int ptindex = pageno%1024;
page_table* pt;
#line 640 "ulix.nw"
if (/* ptindex == 0 && */ ! current_pd->ptds[pdindex].present) {
  // last entry! // create a new page table in the reserved frame
  page_table* pt = (page_table*) PHYSICAL(newframeid<<12);
  memset (pt, 0, PAGE_SIZE);


  // KMAPD ( &(current_pd->ptds[pdindex]), newframeid << 12 );
  
  
  addr_space_id asid;
  page_directory* tmp_pd;
  for (asid=0; asid<1024; asid++) {
    if (address_spaces[asid].status == AS_USED) {  // is this address space in use?
      tmp_pd = address_spaces[asid].pd;
      KMAPD ( &(tmp_pd->ptds[pdindex]), newframeid << 12 );
    }
  }

  newframeid = request_new_frame ();  // get yet another frame
  if (newframeid == -1) {
    return NULL;                      // exit if no frame was found
    // note: we're not removing the new page table since we assume
    // it will be used soon anyway
  }
};
#line 674 "ulix.nw"
pt = (page_table*)( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
// finally: enter the frame address
KMAP ( &(pt->pds[ptindex]), newframeid * PAGE_SIZE );

// invalidate cache entry
asm volatile ("invlpg %0" : : "m"(*(char*)(pageno<<12)) );

memset ((unsigned int*) (pageno*4096), 0, 4096);
return ((unsigned int*) (pageno*4096));
#line 603 "ulix.nw"
}
#line 700 "ulix.nw"
void release_page (unsigned int pageno) {
  int frameno = pageno_to_frameno (pageno);  // we will need this later
  if ( frameno == -1 )  { return; }          // exit if no such page
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  page_table* pt;
  pt = (page_table*)
    ( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
  // write null page descriptor
  memset (&(pt->pds[ptindex]), 0, 4);
  fill_page_desc (&(pt->pds[ptindex]), false, false, false, false, 0);
  release_frame (frameno<<12);   // expects an address, not an ID
  asm volatile ("invlpg %0" : : "m"(*(char*)(pageno<<12)) );
  // gdt_flush ();
};
#line 875 "ulix.nw"
void *memset (void *dest, char val, int count) {
  char *temp = (char *)dest;
  for( ; count != 0; count--) *temp++ = val;
  return dest;
}

void *memsetw (void *dest, short val, int count) {
  short *temp = (short *)dest;
  for( ; count != 0; count--) *temp++ = val;
  return dest;
}
#line 915 "ulix.nw"
void scroll () {
    char *addr;
    for (int i = 0; i < 24; i++) {
      addr = (char*)(VIDEO + i*160);
      memcpy (addr, addr+160, 160);
    }
    unsigned short blank = 0x20 + (0x0f<<8);   // blank character (word)
    memsetw (addr+160, blank, 80);
    posy--;
}

void kputch (char c) {
  char *screen;
  
  if (c=='\n') {
    posy ++;
    if (posy >= 25) scroll ();
    posx = 0;
    uartputc ('\n');  // serielle Konsole
    return;
  }
  
  screen = (char*) (VIDEO + posy*160 + posx*2);
  *screen = c;
  posx++;
  if (posx == 80) { posy++; posx = 0; }
  if (posy >= 25) scroll ();

  // auf serielle Konsole schreiben; ohne Erkl�rung  
  if (c == 0x100) {  //  backspace
    uartputc('\b'); uartputc(' '); uartputc('\b');
  } else uartputc(c);
}
#line 972 "ulix.nw"
void clrscr () {
  posx = posy = 0;
  unsigned blank = 0x20 + (0x0f<<8);   // blank character (word)
  char *screen;
  if (paging_ready)
    screen = (char*) 0xb8000;
  else
    screen = (char*) 0xc0000000 + 0xb8000;
  memsetw (screen, blank, 80*25);
}
#line 1001 "ulix.nw"
void *memcpy (void *dest, const void *src, int count) {
  const char *sp = (const char *)src;
  char *dp = (char *)dest;
  for (; count != 0; count--) 
    *dp++ = *sp++;
  return dest;
}

void *strncpy (void *dest, const void *src, int count) {
  // like memcpy, but copies only until first \0 character
  const char *sp = (const char *)src;
  char *dp = (char *)dest;
  for (; count != 0; count--) {
    *dp = *sp;
    if (*dp == 0) break;
    dp++; sp++;
  }
  return dest;
}
#line 1034 "ulix.nw"
void hexdump (unsigned int start, unsigned int end) {
  char z;
  for (unsigned int i=start; i < end; i+=16) {
    printf ("%x  ", i);  // address
    // hex values
    for (int j=i; j<i+16; j++) {
      printf ("%02x ", (unsigned char)PEEK(j));
      if (j==i+7) kputch (' ');
    };
    kputch (' ');
    // char values
    for (int j=i; j<i+16; j++) {
      z = PEEK(j);
      if ((z>32)&&(z<127)) {
        kputch (PEEK(j));
      } else {
        kputch ('.');
      }
    }
    
    kputch ('\n');
  }
}
#line 1101 "ulix.nw"
unsigned short inportw (unsigned short port) {
  unsigned short retval;
  asm volatile ("inw %%dx, %%ax" : "=a" (retval) : "d" (port));
  return retval;
}

void outportw (unsigned short port, unsigned short data) {
  asm volatile ("outw %%ax, %%dx" : : "d" (port), "a" (data));
}
#line 1193 "ulix.nw"
void fill_idt_entry (unsigned char num, unsigned long address, 
    unsigned short gdtsel, unsigned char flags, unsigned char type) {
  if (num >= 0 && num < 256) {
    idt[num].addr_low  = address & 0xFFFF; // address is the handler address
    idt[num].addr_high = (address >> 16) & 0xFFFF;
    idt[num].gdtsel    = gdtsel;           // GDT sel.: user mode or kernel mode?
    idt[num].zeroes    = 0;
    idt[num].flags     = flags;
    idt[num].type      = type;
  }
}
#line 1253 "ulix.nw"
static void set_irqmask (unsigned short mask) {
  outportb (IO_PIC_MASTER_DATA, (char)(mask % 256) );
  outportb (IO_PIC_SLAVE_DATA,  (char)(mask >> 8)  );
}

unsigned short get_irqmask () {
  return inportb (IO_PIC_MASTER_DATA) 
      + (inportb (IO_PIC_SLAVE_DATA) << 8);
}

static void enable_interrupt (int number) {
  set_irqmask ( 
    get_irqmask ()        // the current value
    & ~(1 << number)      // 16 one-bits, but bit "number" cleared
  );
}
#line 1352 "ulix.nw"
void irq_handler (struct regs *r) {
  int number = r->int_no - 32;                      // interrupt number
  void (*handler)(struct regs *r);                  // type of handler functions

  if (number >= 8)  
    outportb (IO_PIC_SLAVE_CMD, END_OF_INTERRUPT);  // notify slave  PIC
  outportb (IO_PIC_MASTER_CMD, END_OF_INTERRUPT);   // notify master PIC

  handler = interrupt_handlers[number];
  if (handler != NULL)  handler (r);
}
#line 1381 "ulix.nw"
void install_interrupt_handler (int irq, void (*handler)(struct regs *r)) {
  if (irq >= 0 && irq < 16)
    interrupt_handlers[irq] = handler;
}
#line 1485 "ulix.nw"
void fault_handler (struct regs *r) {
  if (r->int_no >= 0 && r->int_no < 32) {
    
#line 1498 "ulix.nw"
printf ("'%s' (%d) Exception at 0x%08x.\n", 
  exception_messages[r->int_no], r->int_no, r->eip);        
printf ("eflags: 0x%08x  errcode: 0x%08x\n", r->eflags, r->err_code);
printf ("eax: %08x  ebx: %08x  ecx: %08x  edx: %08x \n",
  r->eax, r->ebx, r->ecx, r->edx);
printf ("eip: %08x  esp: %08x  int: %8d  err: %8d \n", 
  r->eip, r->esp, r->int_no, r->err_code);
printf ("ebp: %08x  cs: %d  ds: %d  es: %d  fs: %d  ss: %x \n",
  r->ebp, r->cs, r->ds, r->es, r->fs, r->ss);

if (r->int_no == 14) {
  // page fault
  unsigned int faulting_address;
  asm volatile ("mov %%cr2, %0" : "=r" (faulting_address));
  printf ("faulting address (page fault): 0x%x, address space = %d\n",
    faulting_address, current_as);
    
  // The error code gives us details of what happened.
  int present   = !(r->err_code & 0x1); // Page not present
  int rw = r->err_code & 0x2;           // Write operation?
  int us = r->err_code & 0x4;           // Processor was in user-mode?
  int reserved = r->err_code & 0x8;     // Overwritten CPU-reserved bits of page entry?
  int id = r->err_code & 0x10;          // Caused by an instruction fetch?
  printf ("error code: ");

   if (present) {printf("present ");}
   if (rw) {printf("read-only ");}
   if (us) {printf("user-mode ");}
   if (reserved) {printf("reserved ");}
   if (id) {printf("instruction-fetch ");}
  printf ("\n");
}
#line 1488 "ulix.nw"
    printf ("System Stops\n");   
    asm ("cli; \n hlt;");
  }
}
#line 1573 "ulix.nw"
void keyboard_handler (struct regs *r) {
  unsigned char s = inportb (0x60);
  char c;
  if (s < 128)
    c = scancode_table[s];
  else
    c = 0;
  
  if (c != 0 && pos < 256) {
    buffer[pos] = c;
    // printf ("VIDEO = 0x%x, posy = %d\n", VIDEO, posy);
    printf ("%c", c);
    pos++;
    unread++;
  }
  
  return;
};
#line 1644 "ulix.nw"
void kreadline (char *s, int len) {
  int read_chars = 0;
  for (;;) {
    if (pos>0 && buffer[pos-1]=='\n') {
      buffer[pos-1] = 0;  // String terminieren
      strncpy (s, buffer, len);
      pos = 0;
      return;
    }
  }   
}
#line 1679 "ulix.nw"
void install_syscall_handler (int syscallno, void *syscall_handler) {
  if (syscallno < MAX_SYSCALLS) 
    syscall_table[syscallno] = syscall_handler;
  return;
};
#line 1690 "ulix.nw"
void syscall_handler (struct regs *r) {
  void (*handler) (struct regs*);   // handler is a function pointer
  int number = r->eax;
  handler = syscall_table[number];
  if (handler != 0) {
    handler (r);
  } else {
    printf ("Unknown syscall no. eax=0x%x; ebx=0x%x. eip=0x%x, esp=0x%x. "
            "Continuing.\n", r->eax, r->ebx, r->eip, r->esp);
  };
  return;
}
#line 1800 "ulix.nw"
void syscall_printf (struct regs *r) {
  // eax: syscall number, ebx: string address
  char *s = (char*) r->ebx;
  printf ("%s", s);
  return;
}
#line 1818 "ulix.nw"
void syscall_kpeek (struct regs *r) {
  // eax: syscall number, ebx: memory address
  int page = r->ebx / 4096;
  if (pageno_to_frameno (page) == -1)	
    r->eax = -1;	
  else	
    r->eax = (unsigned char)*(char*)(r->ebx);
    // letzte Cast-Operation noetig, damit Werte ueber 128 nicht
    // als negative Werte interpretiert werden (signed char)
}

void syscall_kpoke (struct regs *r) {
  // eax: syscall number, ebx: memory address, ecx: value
  int page = r->ebx / 4096;
  if (pageno_to_frameno (page) != -1)	
    *(char*)(r->ebx) = r->ecx;
}
#line 2525 "ulix.nw"
void syscall_readline (struct regs *r) {
  int address = r->ebx;
  asm volatile ("sti");
  kreadline ((char*)address, 256);
}
#line 2746 "ulix.nw"
void syscall_fork (context_t *r) {
  // unsigned int esp;
  r->ebx = (unsigned int) u_fork(r, false, NULL);   // false: no thread, starts at 0
  printf ("in syscall_fork: returning with ...\n");
  // COPY_ESP_TO_VAR (esp);
  printf ("r->eip     = %08x\n", r->eip);
  printf ("r->esp     = %08x\n", r->esp);
  printf ("r->useresp = %08x\n", r->useresp);
  printf ("r->eax     = %08x\n", r->eax);
  printf ("r->ebx     = %08x\n", r->ebx);
  printf ("r->ecx     = %08x\n", r->ecx);
  
  printf ("PEEK(eip) = %02x\n", PEEK(r->eip));
  
  return;
};
#line 1741 "ulix.nw"
int syscall1 (int eax) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax) );
  return result ;
}

int syscall2 (int eax, int ebx) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax), "b" (ebx) );
  return result ;
}

int syscall3 (int eax, int ebx, int ecx) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax), "b" (ebx), "c" (ecx) );
  return result ;
}

int syscall4 (int eax, int ebx, int ecx, int edx) {
  int result;
  asm ( "int $0x80" : "=a" (result) 
                    : "a" (eax), "b" (ebx), "c" (ecx), "d" (edx) );
  return result ;
}
#line 1855 "ulix.nw"
void userprint (char *s) {
  syscall2 (__NR_printf, (unsigned int)s);
}

int kpeek (unsigned int address) {
  return syscall2 (__NR_kpeek, address);
}

void kpoke (unsigned int address, unsigned char value) {
  syscall3 (__NR_kpoke, address, value);
}
#line 1952 "ulix.nw"
int get_free_address_space () {
  addr_space_id id = 0;
  while ((address_spaces[id].status != AS_FREE) 
         && (id<MAX_ADDR_SPACES)) id++;
  if (id==MAX_ADDR_SPACES) id = -1;
  return id;
}
#line 1987 "ulix.nw"
int create_new_address_space (int initial_ram, int initial_stack) {
  MAKE_MULTIPLE_OF_PAGESIZE (initial_ram);
  MAKE_MULTIPLE_OF_PAGESIZE (initial_stack);
  // reserve address space table entry
  addr_space_id id;
  if ( (id = get_free_address_space()) == -1 )  return -1;    // fail
  address_spaces[id].status    = AS_USED;
  address_spaces[id].memstart  = BINARY_LOAD_ADDRESS;
  address_spaces[id].memend    = BINARY_LOAD_ADDRESS + initial_ram;
  address_spaces[id].stacksize = initial_stack;
  address_spaces[id].refcount  = 1;  // default: used by one process
  
#line 2016 "ulix.nw"
page_directory *new_pd = (void*)request_new_page (0);
if (new_pd == NULL) {  // Error
  printf ("\nERROR: no free page, aborting create_new_address_space\n");
  return -1;
};
memset (new_pd, 0, sizeof(page_directory));
#line 1998 "ulix.nw"
                                              // sets new_pd
  address_spaces[id].pd = new_pd;
  
  
#line 2027 "ulix.nw"
*new_pd = kernel_pd;
new_pd->ptds[0].user_accessible = true;  // Hier ist noch ein Bug,
                                         // die Zeile sollte weg...

#line 2003 "ulix.nw"
  int frameno, pageno;  // used in the following two code chunks
  if (initial_ram > 0)   {  
#line 2046 "ulix.nw"
pageno = 0;
while (initial_ram > 0) {
  if ((frameno = request_new_frame ()) < 0) {
    printf ("\nERROR: no free frame, aborting create_new_address_space\n");
    return -1;
  };
  as_map_page_to_frame (id, pageno, frameno);
  pageno++;
  initial_ram -= PAGE_SIZE;
};
#line 2004 "ulix.nw"
                                                                 }
  if (initial_stack > 0) {  
#line 2059 "ulix.nw"
pageno = TOP_OF_USER_MODE_STACK / PAGE_SIZE;
while (initial_stack > 0) {
  if ((frameno = request_new_frame ()) < 0) {
    printf ("\nERROR: no free frame, aborting create_new_address_space\n");
    return -1;
  };
  pageno--;
  as_map_page_to_frame (id, pageno, frameno);
  initial_stack -= PAGE_SIZE;
}
#line 2005 "ulix.nw"
                                                                   }
  return id;
};
#line 2075 "ulix.nw"
int as_map_page_to_frame (int as, unsigned int pageno, unsigned int frameno) {
  // for address space as, map page #pageno to frame #frameno
  page_table* pt;
  page_directory* pd;

  pd = address_spaces[as].pd;           // use the right address space
  unsigned int pdindex = pageno/1024;   // calculuate pd entry
  unsigned int ptindex = pageno%1024;   // ... and pt entry

  if ( ! pd->ptds[pdindex].present) {
    // page table is not present
    
#line 2104 "ulix.nw"
  int new_frame_id = request_new_frame ();
  unsigned int address = PHYSICAL (new_frame_id << 12);
  pt = (page_table *) address;
  memset (pt, 0, sizeof(page_table));
  UMAPD ( &(pd->ptds[pdindex]), new_frame_id << 12);
#line 2086 "ulix.nw"
                                                      // sets pt
  } else {
    // get the page table
    pt = (page_table*) PHYSICAL(pd->ptds[pdindex].frame_addr << 12);
  };
  if (pdindex < 704)   // address below 0xb0000000 -> user access
    UMAP ( &(pt->pds[ptindex]), frameno << 12 );   // user
  else
    KMAP ( &(pt->pds[ptindex]), frameno << 12 );   // kernel
  return 0;
};
#line 2147 "ulix.nw"
void activate_address_space (addr_space_id id) {
  // NOTE: Do not call this from the scheduler; where needed, replicate the code
  unsigned int virt = (unsigned int)address_spaces[id].pd;  // get PD address
  unsigned int phys = mmu (0, virt);            // and find its physical address

  asm volatile ("mov %0, %%cr3" : : "r"(phys)); // write CR3 register
  current_as = id;                              // set current address space
  current_pd = address_spaces[id].pd;           // set current page directory
  return;
};
#line 2173 "ulix.nw"
unsigned int mmu_p (addr_space_id id, unsigned int pageno) {
  unsigned int pdindex, ptindex;
  page_directory *pd;
  page_table     *pt;
  pdindex = pageno/1024;
  ptindex = pageno%1024;
  pd = address_spaces[id].pd;
  if ( ! pd->ptds[pdindex].present ) {
    return -1;
  } else {
    pt = (page_table*) PHYSICAL(pd->ptds[pdindex].frame_addr << 12);
    if ( pt->pds[ptindex].present ) {
      return pt->pds[ptindex].frame_addr;
    } else {
      return -1;
    };
  }
}

unsigned int mmu (addr_space_id id, unsigned int vaddress) {
  unsigned int tmp = mmu_p (id, (vaddress >> 12));
  if (tmp == -1)
    return -1;  // fail
  else
    return (tmp << 12) + (vaddress % PAGE_SIZE);
}
#line 2284 "ulix.nw"
int register_new_tcb (addr_space_id as_id) {
  // called by ulix_fork() which aquires LOCK (thread_list_lock)
  
#line 2254 "ulix.nw"
boolean tcbfound = false;
int tcbid;
for ( tcbid=next_pid; ((tcbid<MAX_THREADS) 
                       && (!tcbfound));     tcbid++ ) {
  if (thread_table[tcbid].used == false) {
    tcbfound = true;
    break;
  }
};
#line 2266 "ulix.nw"
if (!tcbfound) {                                  // continue searching at 1
  for ( tcbid=1; ((tcbid<next_pid) && (!tcbfound)); tcbid++ ) {
    if (thread_table[tcbid].used == false) {
      tcbfound = true;
      break;
    }
  };
};

if (tcbfound) next_pid = tcbid+1;                 // update next_pid:
// either tcbfound == false or tcbid == index of first free TCB
#line 2287 "ulix.nw"
  if (!tcbfound) {
    return -1; // no free TCB!
  };
  thread_table[tcbid].used       = true;   // mark as used
  thread_table[tcbid].addr_space = as_id;  // enter address space ID
  return tcbid;
}  
#line 2310 "ulix.nw"
void start_program_from_ram (unsigned int address, int size) {
  
#line 2329 "ulix.nw"
addr_space_id as;
thread_id tid;
as = create_new_address_space(64*1024, 4096);   // 64 KB + 4 KB stack
tid = register_new_tcb (as);                    // get a fresh TCB
thread_table[tid].tid = tid;
thread_table[tid].ppid = 0;                     // parent: 0 (none)

activate_address_space (as);                    // activate the new address space
#line 2311 "ulix.nw"
                                                                  
    // this sets tid
  
#line 2343 "ulix.nw"
// read binary
memcpy ((char*)BINARY_LOAD_ADDRESS,
        (char*)address, size);
// load to virtual address 0
#line 2314 "ulix.nw"
  
#line 2363 "ulix.nw"
  unsigned int framenos[KERNEL_STACK_PAGES];   
    // frame numbers of kernel stack pages
  int i; for (i=0; i<KERNEL_STACK_PAGES; i++)
    framenos[i] = request_new_frame();
  /*
  page_table* stackpgtable = (page_table*)request_new_page(0);
  memset (stackpgtable, 0, sizeof(page_table));
  KMAPD ( &current_pd->ptds[767], mmu (0, (unsigned int)stackpgtable) );
  */
  for (i=0; i<KERNEL_STACK_PAGES; i++) {
    as_map_page_to_frame (current_as, 0xbffff - i, framenos[i]);
  }
  char* kstack = (char*) (TOP_OF_KERNEL_MODE_STACK-KERNEL_STACK_SIZE);
  unsigned int adr = (unsigned int)kstack;  // one page for kernel stack

  tss_entry.esp0 = adr+KERNEL_STACK_SIZE;
  
  thread_table[tid].esp0 = (unsigned int)kstack + KERNEL_STACK_SIZE;
  thread_table[tid].ebp  = (unsigned int)kstack + KERNEL_STACK_SIZE;

#line 2316 "ulix.nw"
  current_task = tid;                      // make this the current task  
  printf ("Starting first process with tid %d\n", tid);
  scheduler_is_active = true;
  cpu_usermode (BINARY_LOAD_ADDRESS, 
                TOP_OF_USER_MODE_STACK);   // jump to user mode
};
#line 2431 "ulix.nw"
static void write_tss (int num, unsigned short ss0, unsigned int esp0) {
   unsigned int base = (unsigned int) &tss_entry;
   unsigned int limit = sizeof (tss_entry) - 1;
   fill_gdt_entry (num, base, limit, 0xE9, 0x00);   // enter it in GDT

   memset (&tss_entry, 0, sizeof(tss_entry));       // fill with zeros

   tss_entry.ss0  = ss0;  // Set the kernel stack segment.
   tss_entry.esp0 = esp0; // Set the kernel stack pointer.
} 
#line 2598 "ulix.nw"
int u_fork (context_t *r, boolean create_thread, void *start_address) {
  TCB           *t_old, *t_new;       // pointers to old/new TCB
  int           old_tid, new_tid;     // thread IDs (old/new)
  int           i, j;                 // counters
  unsigned int  eip, esp, ebp;        // temp variables for register values
  addr_space_id old_as, new_as;       // old/new address spaces

  printf ("\nfork: old_tid = %d\n", current_task);
  
#line 2773 "ulix.nw"
asm ("cli");   // clear interrupt flag
#line 2616 "ulix.nw"
// LOCK (thread_list_lock);
old_as = current_as;  old_tid = current_task;  int ppid = old_tid;
  
new_as = create_new_address_space (
  address_spaces[old_as].memend - address_spaces[old_as].memstart,
  address_spaces[old_as].stacksize );  
new_tid = register_new_tcb (new_as);          // TO DO: ERROR CHECK!
printf ("new_tid = %d\n", new_tid);
t_old = &thread_table[old_tid]; t_new = &thread_table[new_tid];
*t_new = *t_old;               // copy the TCB
#line 2640 "ulix.nw"
// get rid of the copying; some data were already setup in register_new_tcb()
t_new->state      = TSTATE_FORK;
t_new->tid        = new_tid;
t_new->ppid       = old_tid;   // set parent process ID
t_new->addr_space = new_as;
t_new->new        = true;      // mark new process as new

// copy current registers to new thread, except EBX (= return value)
t_new->regs       = *r;
t_new->regs.ebx   = 0;         // in the child fork() returns 0

// copy current ESP, EBP
asm volatile("mov %%esp, %0" : "=r"(esp));  // get current ESP
asm volatile("mov %%ebp, %0" : "=r"(ebp));  // get current EBP
t_new->ebp  = ebp;
t_new->esp0 = esp;
// t_new->esp0 = 0xbffffee8;  // ????
#line 2627 "ulix.nw"
// copy the memory
#line 2677 "ulix.nw"
  // create new kernel stack and copy the old one
  page_table* stackpgtable = (page_table*)request_new_page(0);
    // will be removed in destroy_address_space()
  address_spaces[new_as].kstack_pt = (unsigned int)stackpgtable;
  memset (stackpgtable, 0, sizeof(page_table));
  page_directory *tmp_pd;
  tmp_pd = address_spaces[new_as].pd;
  KMAPD ( &tmp_pd->ptds[767], mmu (0, (unsigned int)stackpgtable) );
  
  unsigned int framenos[KERNEL_STACK_PAGES];   // frame numbers of kernel stack pages

  for (i = 0;  i < KERNEL_STACK_PAGES;  i++)
    framenos[i] = request_new_frame();
    //will be removed in destroy_address_space()

  for (i=0; i<KERNEL_STACK_PAGES; i++)
    as_map_page_to_frame (new_as, 0xbffff - i, framenos[i]);

  // copy each page separately: they need not be physically connected or in order
  unsigned int base = 0xc0000000-KERNEL_STACK_SIZE;
  for (i = 0;  i < KERNEL_STACK_PAGES;  i++)
    phys_memcpy ( mmu(new_as, base + i*PAGE_SIZE),
                  mmu(old_as, base + i*PAGE_SIZE), PAGE_SIZE );
#line 2719 "ulix.nw"
  // clone first 3 GB (minus last directory entry) of address space
  page_directory *old_pd, *new_pd;
  page_table     *old_pt, *new_pt;
  old_pd = address_spaces[old_as].pd;
  new_pd = address_spaces[new_as].pd;

  for (i = 0;  i<767;  i++) {          // only 0..766, not 767 (= kstack)
    if (old_pd->ptds[i].present) {
      // walk through the entries of the page table
      old_pt = (page_table*)PHYSICAL(old_pd->ptds[i].frame_addr << 12);
      new_pt = (page_table*)PHYSICAL(new_pd->ptds[i].frame_addr << 12);

      for (j = 0;  j < 1024;  j++)
        if (old_pt->pds[j].present) {
          copy_frame ( new_pt->pds[j].frame_addr, old_pt->pds[j].frame_addr );
        }
    };
  };
#line 2630 "ulix.nw"
// UNLOCK (thread_list_lock);

eip = get_eip ();              // get current EIP
if (current_task == ppid) { 
#line 2664 "ulix.nw"
t_new->eip  = eip;
// add_to_ready_queue (new_tid);
#line 2777 "ulix.nw"
asm ("sti");   // set interrupt flag
#line 2666 "ulix.nw"
                                 // must be done in parent
return new_tid;                // in parent, fork() return child's PID
#line 2633 "ulix.nw"
                                                        } 
else                      { 
#line 2671 "ulix.nw"
/* 
#line 2777 "ulix.nw"
asm ("sti");   // set interrupt flag
#line 2671 "ulix.nw"
                                                     */
return 0;                      // in child, fork() returns 0
#line 2634 "ulix.nw"
                                                       }
#line 2607 "ulix.nw"
}
#line 2807 "ulix.nw"
void scheduler (context_t *r, int source) {
  
#line 2773 "ulix.nw"
asm ("cli");   // clear interrupt flag
#line 2809 "ulix.nw"
  // printf ("ENTER scheduler\n");
  
#line 2816 "ulix.nw"
// check if we want to run the scheduler
if (!scheduler_is_active)  return;
//if (!thread_table[2].used) return;   // are there already two threads?

t_old = &thread_table[current_task];
#line 2831 "ulix.nw"
int tid = current_task;  // start search at current task
tid = 3-tid;   // abwechselnd 1, 2
t_new = &thread_table[tid];
#line 2822 "ulix.nw"
if (t_new != t_old) { 
#line 2848 "ulix.nw"
// printf ("ENTER context switch, switch from %d to %d\n",
//   t_old->tid, t_new->tid);
t_old->regs = *r;               // store old:   registers
COPY_ESP_TO_VAR (t_old->esp0);  //              esp (kernel)
COPY_EBP_TO_VAR (t_old->ebp);   //              ebp

current_task = t_new->tid;
current_as   = t_new->addr_space;
current_pd   = address_spaces[t_new->addr_space].pd;
WRITE_CR3 ( mmu (0, (unsigned int)current_pd) );   // activate address space
gdt_flush ();
COPY_VAR_TO_ESP (t_new->esp0);  // restore new: esp
COPY_VAR_TO_EBP (t_new->ebp);   //              ebp
*r = t_new->regs;               //              registers

if (t_new->new) { 
#line 2868 "ulix.nw"
  printf ("This process is new!\n");
  printf ("current_task = %d\n", current_task);
  t_new->new = false;
  // asm ("add %esp, 4");
  asm ("push %0" : : "r"(thread_table[current_task].eip));
  asm ("ret");
#line 2863 "ulix.nw"
                                                                    }
// printf ("LEAVE context switch\n");
#line 2822 "ulix.nw"
                                                    }
// <<scheduler: free old kernel stacks>>  // if there are any 
return;
#line 2811 "ulix.nw"
  // printf ("LEAVE scheduler\n");
}
#line 2957 "ulix.nw"
static inline void repeat_inportsl (int port, void *addr, int cnt) {
  asm volatile("cld \n"
               "rep insl" :
               "=D" (addr), "=c" (cnt) :
               "d" (port), "0" (addr), "1" (cnt) :
               "memory", "cc");
}

static inline void repeat_outportsl (int port, void *addr, int cnt) {
  asm volatile("cld \n"
               "rep outsl" :
               "=S" (addr), "=c" (cnt) :
               "d" (port), "0" (addr), "1" (cnt) :
               "cc");
}
#line 3005 "ulix.nw"
void readsector_hd (int hd, int sector, char* buffer) {
  hd_direction = HD_OP_READ;
  
#line 2921 "ulix.nw"
idewait (0);
outportb (IO_IDE_DISKSEL,   0xe0 | (hd<<4));   // select disk
outportb (IO_IDE_DEVCTRL,   0);                // generate interrupt
outportb (IO_IDE_SEC_COUNT, 1);                // one sector
outportb (IO_IDE_SECTOR,     sector        & 0xff);
outportb (IO_IDE_SECTOR+1,  (sector >> 8)  & 0xff);
outportb (IO_IDE_SECTOR+2,  (sector >> 16) & 0xff);
outportb (IO_IDE_SECTOR+3, ((sector >> 24) & 0x0f) | ((0xe + hd) << 4) );
#line 2936 "ulix.nw"
outportb (IO_IDE_COMMAND, IDE_CMD_READ);
#line 3008 "ulix.nw"
  while (hd_direction == HD_OP_READ) { printf ("."); };
  
#line 3030 "ulix.nw"
idewait (0);
repeat_inportsl (IO_IDE_DATA, hd_buf, HD_SECSIZE / 4);
inportb         (IO_IDE_STATUS);  // read status, ack irq
#line 3010 "ulix.nw"
  memcpy (buffer, hd_buf, HD_SECSIZE);
  hd_direction = HD_OP_NONE;
}
#line 3016 "ulix.nw"
void writesector_hd (int hd, int sector, char* buffer) {
  hd_direction = HD_OP_WRITE;
  memcpy (hd_buf, buffer, HD_SECSIZE);
  
#line 2921 "ulix.nw"
idewait (0);
outportb (IO_IDE_DISKSEL,   0xe0 | (hd<<4));   // select disk
outportb (IO_IDE_DEVCTRL,   0);                // generate interrupt
outportb (IO_IDE_SEC_COUNT, 1);                // one sector
outportb (IO_IDE_SECTOR,     sector        & 0xff);
outportb (IO_IDE_SECTOR+1,  (sector >> 8)  & 0xff);
outportb (IO_IDE_SECTOR+2,  (sector >> 16) & 0xff);
outportb (IO_IDE_SECTOR+3, ((sector >> 24) & 0x0f) | ((0xe + hd) << 4) );
#line 2941 "ulix.nw"
outportb (IO_IDE_COMMAND, IDE_CMD_WRITE);
#line 3020 "ulix.nw"
  
#line 3036 "ulix.nw"
inportb          (IO_IDE_STATUS);    // read status, ack irq
repeat_outportsl (IO_IDE_DATA, hd_buf, HD_SECSIZE / 4);
inportb          (IO_IDE_STATUS);    // read status, ack irq
#line 3021 "ulix.nw"
  while (hd_direction == HD_OP_WRITE) {};
  hd_direction = HD_OP_NONE;
}
#line 3048 "ulix.nw"
static int idewait (int checkerr) {
  int r;
  outportb (IO_IDE_DISKSEL, 0xe0);  // query disk 0
  while (((r = inportb(IO_IDE_STATUS)) 
        & (IDE_BSY|IDE_DRDY)) != IDE_DRDY) 
    printf ("=");
  if (checkerr && (r & (IDE_DF|IDE_ERR)) != 0) {
    return -1;
  }
  return 0;
}
#line 3069 "ulix.nw"
void ide_handler (context_t *r) {
  printf ("IDE_HANDLER\n");
  switch (hd_direction) {
    case HD_OP_READ:  
#line 2773 "ulix.nw"
asm ("cli");   // clear interrupt flag
#line 3073 "ulix.nw"
                      // repeat_inportsl (IO_IDE_DATA, hd_buf, HD_SECSIZE / 4);
                      hd_direction = HD_OP_NONE;
                      break;

    case HD_OP_WRITE: 
#line 2773 "ulix.nw"
asm ("cli");   // clear interrupt flag
#line 3078 "ulix.nw"
                      hd_direction = HD_OP_NONE;
                      break;

    case HD_OP_NONE:  printf ("FUNNY IDE INTERRUPT -- NO REQUEST WAITING\n");
                      return; 
  }

  
#line 2777 "ulix.nw"
asm ("sti");   // set interrupt flag
#line 3086 "ulix.nw"
}
#line 742 "ulix.nw"
int main () {
  
#line 900 "ulix.nw"
posx = 0; posy = 8;  // set cursor
#line 744 "ulix.nw"
  printf ("[1] entering main()\n");

  
#line 345 "ulix.nw"
for (int i=1; i<1024; i++) {
  fill_page_table_desc (&(current_pd->ptds[i]), false, false, false, 0);
};
#line 356 "ulix.nw"
KMAPD ( &(current_pd->ptds[  0]), (unsigned int)(current_pt)-0xC0000000 );
KMAPD ( &(current_pd->ptds[768]), (unsigned int)(current_pt)-0xC0000000 );
#line 364 "ulix.nw"
for (int i=0; i<1023; i++) {
  KMAP ( &(current_pt->pds[i]), i*4096 );
};
printf ("[2] page directory setup, with identity mapping\n");
#line 375 "ulix.nw"
unsigned int cr0;
char *kernel_pd_address;
kernel_pd_address = (char*)(current_pd) - 0xC0000000;
asm volatile ("mov %0, %%cr3" : : "r"(kernel_pd_address)); 
  // write CR3
asm volatile ("mov %%cr0, %0" : "=r"(cr0) : );  // read  CR0
cr0 |= (1<<31);      // Enable paging by setting PG bit 31 of CR0
asm volatile ("mov %0, %%cr0" : : "r"(cr0) );   // write CR0
printf ("[3] paging activated.\n");
#line 1962 "ulix.nw"
address_spaces[0].status   = AS_USED;
address_spaces[0].pd       = &kernel_pd;
address_spaces[0].pid      = -1;         // not a process
#line 747 "ulix.nw"
  
#line 162 "ulix.nw"
gdt_install ();
#line 747 "ulix.nw"
                                // replace "trick GDT" with regular GDT

  paging_ready = true;
  printf ("[4] regular GDT is active\n");
  VIDEO = 0xb8000;  // Segmentierung nicht mehr noetig

  
  
#line 786 "ulix.nw"
memset (kernel_pt_ram, 0, 4);

for (unsigned int fid=0; fid<NUMBER_OF_FRAMES; fid++) {
  KMAP ( &(kernel_pt_ram[fid/1024].pds[fid%1024]), fid*PAGE_SIZE );
}
unsigned int physaddr;
for (int i=0; i<16; i++) {
  // get physical address of kernel_pt_ram[i]
  physaddr = (unsigned int)(&(kernel_pt_ram[i])) - 0xc0000000;
  KMAPD ( &(current_pd->ptds[832+i]), physaddr );
};

gdt_flush ();
#line 755 "ulix.nw"
  
  printf ("[5] going to remove map 0->0... ");
  fill_page_table_desc (&current_pd->ptds[0], 0, 0, 0, 0);
  printf ("done\n");
  
  VIDEO = PHYSICAL (0xb8000);

  
#line 810 "ulix.nw"
  memset (ftable, 0, NUMBER_OF_FRAMES/8);  // all frames are free
  memset (ftable, 0xff, 128);
  free_frames -= 1024;
#line 763 "ulix.nw"
  
#line 1392 "ulix.nw"
idtp.limit = (sizeof (struct idt_entry) * 256) - 1;   // must do -1
idtp.base  = (int) &idt;
idt_load ();
#line 1438 "ulix.nw"
FILL_IDT( 0); FILL_IDT( 1); FILL_IDT( 2); FILL_IDT( 3); FILL_IDT( 4); 
FILL_IDT( 5); FILL_IDT( 6); FILL_IDT( 7); FILL_IDT( 8); FILL_IDT( 9);
FILL_IDT(10); FILL_IDT(11); FILL_IDT(12); FILL_IDT(13); FILL_IDT(14); 
FILL_IDT(15); FILL_IDT(16); FILL_IDT(17); FILL_IDT(18); FILL_IDT(19);
FILL_IDT(20); FILL_IDT(21); FILL_IDT(22); FILL_IDT(23); FILL_IDT(24);
FILL_IDT(25); FILL_IDT(26); FILL_IDT(27); FILL_IDT(28); FILL_IDT(29);
FILL_IDT(30); FILL_IDT(31); FILL_IDT(128);
#line 1134 "ulix.nw"
outportb (IO_PIC_MASTER_CMD,  0x11);  // ICW1: initialize; begin programming
outportb (IO_PIC_SLAVE_CMD,   0x11);  // ICW1: dito, for PIC2
outportb (IO_PIC_MASTER_DATA, 0x20);  // ICW2 for PIC1: offset 0x20 
                                      // (remaps 0x00..0x07 -> 0x20..0x27)
outportb (IO_PIC_SLAVE_DATA,  0x28);  // ICW2 for PIC2: offset 0x28 
                                      // (remaps 0x08..0x0f -> 0x28..0x2f)
outportb (IO_PIC_MASTER_DATA, 0x04);  // ICW3 for PIC1: there's a slave on IRQ 2 
                                      // (0b00000100 = 0x04)
outportb (IO_PIC_SLAVE_DATA,  0x02);  // ICW3 for PIC2: your slave ID is 2
outportb (IO_PIC_MASTER_DATA, 0x01);  // ICW4 for PIC1 and PIC2: 8086 mode
outportb (IO_PIC_SLAVE_DATA,  0x01);
#line 1150 "ulix.nw"
outportb (IO_PIC_MASTER_DATA, 0x00);  // PIC1: mask 0
outportb (IO_PIC_SLAVE_DATA,  0x00);  // PIC2: mask 0
#line 1223 "ulix.nw"
set_irqmask (0xFFFF);           // initialize IRQ mask
enable_interrupt (IRQ_SLAVE);   // IRQ slave

// flags: 1 (present), 11 (DPL 3), 0; type: 1110 (32 bit interrupt gate)
fill_idt_entry (32, (unsigned int)irq0,  0x08, 0b1110, 0b1110);
fill_idt_entry (33, (unsigned int)irq1,  0x08, 0b1110, 0b1110);
fill_idt_entry (34, (unsigned int)irq2,  0x08, 0b1110, 0b1110);
fill_idt_entry (35, (unsigned int)irq3,  0x08, 0b1110, 0b1110);
fill_idt_entry (36, (unsigned int)irq4,  0x08, 0b1110, 0b1110);
fill_idt_entry (37, (unsigned int)irq5,  0x08, 0b1110, 0b1110);
fill_idt_entry (38, (unsigned int)irq6,  0x08, 0b1110, 0b1110);
fill_idt_entry (39, (unsigned int)irq7,  0x08, 0b1110, 0b1110);
fill_idt_entry (40, (unsigned int)irq8,  0x08, 0b1110, 0b1110);
fill_idt_entry (41, (unsigned int)irq9,  0x08, 0b1110, 0b1110);
fill_idt_entry (42, (unsigned int)irq10, 0x08, 0b1110, 0b1110);
fill_idt_entry (43, (unsigned int)irq11, 0x08, 0b1110, 0b1110);
fill_idt_entry (44, (unsigned int)irq12, 0x08, 0b1110, 0b1110);
fill_idt_entry (45, (unsigned int)irq13, 0x08, 0b1110, 0b1110);
fill_idt_entry (46, (unsigned int)irq14, 0x08, 0b1110, 0b1110);
fill_idt_entry (47, (unsigned int)irq15, 0x08, 0b1110, 0b1110);
#line 1544 "ulix.nw"
install_interrupt_handler (IRQ_KBD, keyboard_handler);
enable_interrupt (IRQ_KBD);
printf ("ENABLE INTERRUPTS\n");
asm ("sti");
#line 3094 "ulix.nw"
install_interrupt_handler (IRQ_IDE, ide_handler);
enable_interrupt (IRQ_IDE);
#line 764 "ulix.nw"
  
#line 823 "ulix.nw"
/*
printf ("TEST req_frame: free_frames = %d, ", free_frames);
int fid = request_new_frame ();
printf ("frameid = 0x%x, free_frames = %d\n", fid, free_frames);

printf ("TEST req_page:  free_frames = %d, ", free_frames);
unsigned int *address = request_new_page (0);
printf ("addr = 0x%x, free_frames = %d\n", address, free_frames);
  
// Use new page for a string
memset (address, 'z', PAGE_SIZE);
char *string = (char *)address; string[10] = 0;
printf ("Test-String of 10 'z's: %s  -- address: 0x%x\n", 
  string, (unsigned int)string);
printf ("pageno_to_frameno (0x%x) = 0x%x\n", 
  (unsigned int)address >> 12, 
  pageno_to_frameno ((unsigned int)address >> 12));
  
release_page ((unsigned int)address >> 12);
printf ("After release_page (0x%x): free_frames = %d\n", 
  (unsigned int)address >> 12, free_frames);
printf ("pageno_to_frameno (0x%x) = %d  (-1: not mapped)\n", 
  (unsigned int)address >> 12, 
  pageno_to_frameno ((unsigned int)address >> 12));
*/
#line 765 "ulix.nw"
  
#line 1843 "ulix.nw"
install_syscall_handler (__NR_printf, syscall_printf);
install_syscall_handler (__NR_kpeek,  syscall_kpeek);
install_syscall_handler (__NR_kpoke,  syscall_kpoke);
#line 2540 "ulix.nw"
install_syscall_handler (__NR_readline, syscall_readline);
#line 2768 "ulix.nw"
install_syscall_handler (__NR_fork, syscall_fork);
#line 3102 "ulix.nw"
// auf User Mode umschalten: deaktiviert
// printf ("Entering User Mode...\n");
// start_program_from_ram ((unsigned int)usermodeprog,
//   sizeof(usermodeprog));
char buffer[512];
printf ("calling readsector\n");
readsector_hd (0, 0, buffer);
writesector_hd (1, 10, buffer);
buffer[511] = 0;  // fuer printf-Ausgabe
printf ("ok. head(buffer): \n%s\n", buffer);

for (;;);
#line 766 "ulix.nw"
  for (;;);   // inifinite loop
}
