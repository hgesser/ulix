// mkfs.rsf
// create file system image for RSF (the ridiculously simple filesystem)
// v0.2, 2013/01/07, Hans-Georg Esser

#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
     
typedef unsigned short uint16;

typedef struct {
  char name[12];  // filename
  uint16 size;    // file size in bytes
  uint16 sector;  // start sector
} simplefs_fat_entry;

simplefs_fat_entry e1,e2;

char progname[50];

void error (char* message, int exitcode) {
  printf ("%s: error: %s\n", progname, message);
  exit (exitcode);
};

void error2 (char* message, char* filename, int exitcode) {
  printf ("%s: error: %s: %s\n", progname, message, filename);
  exit (exitcode);
};

int main (int argc, char *argv[]) {
  simplefs_fat_entry e;
  struct stat s;
  
  strcpy ((char*)&progname, argv[0]);
  
  if (argc<3) {
    printf ("%s: %s imagename file [file] ...\n", argv[0], argv[0]);
    exit(1);
  };

  char* imagename = argv[1];
  int files = argc-2;
  
  // printf ("Image name: %s, Files: %d\n", imagename, files);

  int image, fd;
  image = open (imagename, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
  if (image==-1) {
    error2 ("cannot open image file", imagename, 1);
  };
  int i, nbytes;
  int sec = 1;  // first data sector is 1
  char buf[512];
  char errmessage[128];
  char filename[13];  // up to 12 characters + \0
  
  #define FILENAME argv[i+2]
  for (i=0; i<files; i++) {
    if (strlen(FILENAME) > 12) {
      printf ("skipping '%s', max. filename length is 12\n", argv[i+2]);
      continue; // skip this file
    }
    strcpy (e.name, FILENAME);
    lstat (FILENAME, &s);
    e.size = s.st_size;
    e.sector = sec;
    sec = sec + (e.size+511)/512;  // how many sectors does the file use?

    // write FAT entry
    lseek (image, i*16, SEEK_SET);
    write (image, &e, 16);
    
    // write file
    lseek (image, e.sector*512, SEEK_SET);
    fd = open (FILENAME, O_RDONLY);
    if (fd==-1) {
      // strcpy ((char*)&errmessage, "cannot open source file: ");
      // strcat ((char*)&errmessage, e.name);
      error2 ("cannot open source file", e.name, 1);
    };
    for (;;) {
      nbytes = read (fd, &buf, 512);
      write (image, &buf, nbytes);
      if (nbytes==0) break;
      if (nbytes<512) {
        // padding
        memset (&buf, 0, 512-nbytes);
        write (image, &buf, 512-nbytes);
      };
    };
    close (fd);
  };

  #ifdef ENLARGE_IMAGE
  // make image 1.44 MB large
  fstat (image, &s);
  if (s.st_size != 1440*1024) {
    lseek (image, 1440*1024 - 1, SEEK_SET);
    write (image, "0", 1);
  };  
  #endif
  
  close (image);
  return 0;
};

