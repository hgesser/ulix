#define false 0
#define true 1
#define MEM_SIZE 1024*1024*64        // 64 MByte
#define MAX_ADDRESS MEM_SIZE-1       // last valid physical address
#define PAGE_SIZE 4096               // Intel: 4K pages
#define NUMBER_OF_FRAMES MEM_SIZE/PAGE_SIZE
#define asm __asm__
#define volatile __volatile__
#define NULL ((void*) 0)
#define IRQ_TIMER      0
#define IRQ_KBD        1
#define IRQ_SLAVE      2     // Here the slave PIC connects to master
#define IRQ_COM2       3
#define IRQ_COM1       4
#define IRQ_FDC        6
#define IRQ_IDE       14     // primary IDE controller; secondary has IRQ 15
// I/O Addresses of the two programmable interrupt controllers
#define IO_PIC_MASTER_CMD   0x20  // Master (IRQs 0-7), command register
#define IO_PIC_MASTER_DATA  0x21  // Master, control register

#define IO_PIC_SLAVE_CMD    0xA0  // Slave (IRQs 8-15), command register
#define IO_PIC_SLAVE_DATA   0xA1  // Slave, control register
#define END_OF_INTERRUPT  0x20
#define KEY_UP     191
#define KEY_DOWN   192
#define KEY_LEFT   193
#define KEY_RIGHT  194
#define MAX_SYSCALLS 0x8000         // max syscall number: 0x7fff
struct gdt_entry {
  unsigned int limit_low   : 16;
  unsigned int base_low    : 16;
  unsigned int base_middle :  8;
  unsigned int access      :  8;
  unsigned int flags       :  4;
  unsigned int limit_high  :  4;
  unsigned int base_high   :  8;
};

struct gdt_ptr {
  unsigned int limit       : 16;
  unsigned int base        : 32;
} __attribute__((packed));
typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int undocumented   :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_table_desc;

typedef struct { page_table_desc ptds[1024]; } page_directory;
typedef struct {
  unsigned int present         : 1;  //  0
  unsigned int writeable       : 1;  //  1
  unsigned int user_accessible : 1;  //  2
  unsigned int pwt            :  1;  //  3
  unsigned int pcd            :  1;  //  4
  unsigned int accessed       :  1;  //  5
  unsigned int dirty          :  1;  //  6
  unsigned int zeroes         :  2;  //  8.. 7
  unsigned int unused_bits    :  3;  // 11.. 9
  unsigned int frame_addr     : 20;  // 31..12
} page_desc;

typedef struct { page_desc pds[1024]; } page_table;
typedef unsigned int boolean;
struct idt_entry {
    unsigned int addr_low  : 16;   // lower 16 bits of address
    unsigned int gdtsel    : 16;   // use which GDT entry?
    unsigned int zeroes    :  8;   // must be set to 0
    unsigned int type      :  4;   // type of descriptor
    unsigned int flags     :  4;
    unsigned int addr_high : 16;   // higher 16 bits of address
} __attribute__((packed));
struct idt_ptr {
    unsigned int limit   : 16;
    unsigned int base    : 32;
} __attribute__((packed));
struct regs {
  unsigned int gs, fs, es, ds;
  unsigned int edi, esi, ebp, esp, ebx, edx, ecx, eax;
  unsigned int int_no, err_code;
  unsigned int eip, cs, eflags, useresp, ss;
};
struct gdt_entry gdt[6];
struct gdt_ptr gp;
page_directory kernel_pd     __attribute__ ((aligned (4096)));
page_table kernel_pt         __attribute__ ((aligned (4096)));
page_table kernel_pt_ram[16] __attribute__ ((aligned (4096)));

page_directory* current_pd = &kernel_pd;
page_table*     current_pt = &kernel_pt;
unsigned int free_frames = NUMBER_OF_FRAMES;
char place_for_ftable[NUMBER_OF_FRAMES/8];
unsigned int* ftable = (unsigned int*)(&place_for_ftable);
int paging_ready = false;
int posx, posy;
struct idt_entry idt[256] = { 0 };
struct idt_ptr idtp;
void *interrupt_handlers[16] = { 0 };
char *exception_messages[] = {
  "Division By Zero",       "Debug",                        //  0,  1
  "Non Maskable Interrupt", "Breakpoint",                   //  2,  3
  "Into Detected Overflow", "Out of Bounds",                //  4,  5
  "Invalid Opcode",         "No Coprocessor",               //  6,  7
  "Double Fault",           "Coprocessor Segment Overrun",  //  8,  9
  "Bad TSS",                "Segment Not Present",          // 10, 11
  "Stack Fault",            "General Protection Fault",     // 12, 13
  "Page Fault",             "Unknown Interrupt",            // 14, 15
  "Coprocessor Fault",      "Alignment Check",              // 16, 17
  "Machine Check",                                          // 18
  "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
  "Reserved", "Reserved", "Reserved", "Reserved", "Reserved",
  "Reserved", "Reserved", "Reserved"                        // 19..31
};
unsigned long int ticks = 0;
char scancode_table[128] = { 
  /*  0.. 9 */    0,  27, '1', '2', '3', '4', '5', '6', '7', '8',
  /* 10..19 */   '9', '0', '-', '=', '\b',       /* Backspace */
                 '\t', /* Tab */   'q', 'w', 'e', 'r',  
  /* 20..29 */   't', 'z', 'u', 'i', 'o', 'p', '[', ']', 
                 '\n', /* Enter */  0, /* Control */
  /* 30..39 */   'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';',
  /* 40..49 */   '\'', '`', 0, /* Left shift */  '\\', 'y', 'x', 
                 'c', 'v', 'b', 'n',
  /* 50..59 */   'm', ',', '.', '/', 0, /* Right shift */
                 '*', 0, /* Alt */  ' ', /* Space bar */
                 0, /* CapsLock */  0, /* F1 */
  /* 60..69 */   0, 0, 0, 0, 0, 0, 0, 0, 0, /* F2..F10 */
                 0, /* NumLock */
  /* 70..79 */   0, /* Scroll Lock */   0, /* Home key */
                 KEY_UP, 0, /* Page Up */
                 '-', KEY_LEFT, 0, KEY_RIGHT,
                 '+', 0, /* End */
  /* 80..89 */   KEY_DOWN, 0, /* Page Down */
                 0, /* Insert Key */    0, /* Delete */
                 0, 0, 0, 0, /* F11 */  0, /* F12 */   0,
  /* 90..127     not defined */
};   // Scan Codes
short int pos = 0;                  // Puffer-Position
short int unread = 0;               // Anzahl "frischer" Zeichen
char buffer[256] = { 0 };           // Eingabe-Puffer
void *syscall_table[MAX_SYSCALLS];
#define KMAP(pd,frame) \
  fill_page_desc (pd, true, true, false, false, frame)
#define KMAPD(ptd, frame) \
  fill_page_table_desc (ptd, true, true, false, frame)
#define INDEX_FROM_BIT(b) (b/32)   // 32 bits in an unsigned int
#define OFFSET_FROM_BIT(b) (b%32)
#define PHYSICAL(x) ((x)+0xd0000000)
#define PEEK(addr) (*(unsigned char *)(addr))
#define FILL_IDT(i) \
  fill_idt_entry (i, (unsigned int)isr##i, 0x08, 0b1110, 0b1110)
extern void gdt_flush();
void gdt_set_gate (int num, unsigned long base, 
  unsigned long limit, unsigned char access, unsigned char gran);
void gdt_install ();
page_table_desc* fill_page_table_desc (page_table_desc *ptd, 
  unsigned int present, unsigned int writeable, 
  unsigned int user_accessible, unsigned int frame_addr);
page_desc* fill_page_desc (page_desc *pd, unsigned int present,
  unsigned int writeable, unsigned int user_accessible,
  unsigned int dirty, unsigned int frame_addr);
static void set_frame (unsigned int frame_addr);
static void clear_frame (unsigned int frame_addr);
static unsigned int test_frame (unsigned int frame_addr);
int request_new_frame ();
void release_frame (unsigned int frameaddr);
unsigned int pageno_to_frameno (unsigned int pageno);
unsigned int* request_new_page (int need_more_pages);
void release_page (unsigned int pageno);
void *memset  (void *dest, char val,  int count);
void *memsetw (void *dest, short val, int count);
extern int printf(const char *format, ...);
void kputch (char c);
extern void uartputc (int c);
void clrscr ();
void *strncpy(void *dest, const void *src, int count);
void hexdump (unsigned int start, unsigned int end);
unsigned char  inportb (unsigned short port);
unsigned short inportw (unsigned short port);
void outportb (unsigned short port, unsigned char data);
void outportw (unsigned short port, unsigned short data);
void fill_idt_entry (unsigned char num, unsigned long address, 
    unsigned short gdtsel, unsigned char flags, unsigned char type);
extern void irq0(), irq1(), irq2(),  irq3(),  irq4(),  irq5(),  irq6(),  irq7();
extern void irq8(), irq9(), irq10(), irq11(), irq12(), irq13(), irq14(), irq15();
static void set_irqmask (unsigned short mask);
static void enable_interrupt (int number);
unsigned short get_irqmask ();
void install_interrupt_handler (int irq, void (*handler)(struct regs *r));
extern void idt_load ();
extern void isr0(),  isr1(),  isr2(),  isr3(),  isr4(),  isr5(),  
   isr6(),  isr7(),  isr8(),  isr9(),  isr10(), isr11(), isr12(), 
   isr13(), isr14(), isr15(), isr16(), isr17(), isr18(), isr19(), 
   isr20(), isr21(), isr22(), isr23(), isr24(), isr25(), isr26(), 
   isr27(), isr28(), isr29(), isr30(), isr31(), isr128();
void fault_handler (struct regs *r);
void keyboard_handler (struct regs *r);
void timer_handler (struct regs *r);
void kreadline (char *s, int len);
void install_syscall_handler (int syscallno, void *syscall_handler);
// Hier fuegen Sie die Prototypen ein
int syscall1 (int eax);
int syscall2 (int eax, int ebx);
int syscall3 (int eax, int ebx, int ecx);
int syscall4 (int eax, int ebx, int ecx, int edx);
void gdt_set_gate(int num, unsigned long base, unsigned long limit,
                  unsigned char access, unsigned char gran) {
  /* Setup the descriptor base address */
  gdt[num].base_low = (base & 0xFFFF);            // 16 bits
  gdt[num].base_middle = (base >> 16) & 0xFF;     //  8 bits
  gdt[num].base_high = (base >> 24) & 0xFF;       //  8 bits

  /* Setup the descriptor limits */
  gdt[num].limit_low  = (limit & 0xFFFF);         // 16 bits
  gdt[num].limit_high = ((limit >> 16) & 0x0F);   //  4 bits

  /* Finally, set up the granularity and access flags */
  gdt[num].flags = gran & 0xF;
  gdt[num].access = access;
}

void gdt_install() {
  gp.limit = (sizeof(struct gdt_entry) * 6) - 1;
  gp.base = (int) &gdt;

  gdt_set_gate(0, 0, 0, 0, 0);    // NULL descriptor

  // code segment
  gdt_set_gate(1, 0, 0xFFFFFFFF, 0b10011010, 0b1100 /* 0xCF */);

  // data segment
  gdt_set_gate(2, 0, 0xFFFFFFFF, 0b10010010, 0b1100 /* 0xCF */);

  gdt_flush();
}
page_desc* fill_page_desc (page_desc *pd, unsigned int present,
  unsigned int writeable, unsigned int user_accessible,
  unsigned int dirty, unsigned int frame_addr) {

  memset (pd, 0, sizeof(pd));
  
  pd->present = present;
  pd->writeable = writeable;
  pd->user_accessible = user_accessible;
  pd->dirty = dirty;
  pd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
  return pd;
};

page_table_desc* fill_page_table_desc (page_table_desc *ptd, 
  unsigned int present, unsigned int writeable, 
  unsigned int user_accessible, unsigned int frame_addr) {

  memset (ptd, 0, sizeof(ptd));
  
  ptd->present = present;
  ptd->writeable = writeable;
  ptd->user_accessible = user_accessible;
  ptd->frame_addr = frame_addr >> 12;   // right shift, 12 bits
  return ptd;
};
static void set_frame (unsigned int frame_addr) {
  unsigned int frame = frame_addr / PAGE_SIZE;
  unsigned int index  = INDEX_FROM_BIT  (frame);
  unsigned int offset = OFFSET_FROM_BIT (frame);
  ftable[index] |= (1 << offset);
}

static void clear_frame (unsigned int frame_addr) {
  unsigned int frame = frame_addr / PAGE_SIZE;
  unsigned int index  = INDEX_FROM_BIT  (frame);
  unsigned int offset = OFFSET_FROM_BIT (frame);
  ftable[index] &= ~(1 << offset);
}

static unsigned int test_frame (unsigned int frame_addr) {
  // returns true if frame is in use (false if frame is free)
  unsigned int frame = frame_addr / PAGE_SIZE;
  unsigned int index  = INDEX_FROM_BIT  (frame);
  unsigned int offset = OFFSET_FROM_BIT (frame);
  return ((ftable[index] & (1 << offset)) >> offset);
}
int request_new_frame () {
  unsigned int frameid;
  boolean found=false;
  for (frameid = 0; frameid < NUMBER_OF_FRAMES; frameid++) {
    if ( !test_frame (frameid*4096) ) {
      found=true;
      break;   // frame found
    };
  }
  if (found) {
    memset ((void*)PHYSICAL(frameid << 12), 0, PAGE_SIZE);
    set_frame (frameid*4096);
    free_frames--;
    return frameid;
  } else {
    return -1;
  }
};

void release_frame (unsigned int frameaddr) {
  if ( test_frame (frameaddr) ) {
    // only do work if frame is marked as used
    clear_frame (frameaddr);
    free_frames++;
  };
};
unsigned int pageno_to_frameno (unsigned int pageno) {
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  if ( ! current_pd->ptds[pdindex].present ) {
    return -1;       // we don't have that page table
  } else {
    // get the page table
    page_table* pt = (page_table*)
      ( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
    if ( pt->pds[ptindex].present ) {
      return pt->pds[ptindex].frame_addr;
    } else {
      return -1;     // we don't have that page
    };
  };    
};
unsigned int* request_new_page (int need_more_pages) {
  unsigned int newframeid = request_new_frame ();
  if (newframeid == -1) { return NULL; }  // exit if no frame was found
  unsigned int pageno = -1;
  for (unsigned int i=0xc0000; i<1024*1024; i++) {
    if ( pageno_to_frameno (i) == -1 ) {
      pageno = i;
      break;       // end loop, unmapped page was found
    };
  };

  if ( pageno == -1 ) {
    return NULL;   // we found no page -- whole 4 GB are mapped???
  };
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  page_table* pt;
  if (ptindex == 0) {
    // last entry! // create a new page table in the reserved frame
    page_table* pt = (page_table*) PHYSICAL(newframeid<<12);
    memset (pt, 0, PAGE_SIZE);
    KMAPD ( &(current_pd->ptds[pdindex]), newframeid << 12 );

    newframeid = request_new_frame ();  // get yet another frame
    if (newframeid == -1) {
      return NULL;                      // exit if no frame was found
      // note: we're not removing the new page table since we assume
      // it will be used soon anyway
    }
  };
  pt = (page_table*)( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
  // finally: enter the frame address
  KMAP ( &(pt->pds[ptindex]), newframeid * PAGE_SIZE );

  // invalidate cache entry
  asm volatile ("invlpg %0" : : "m"(*(char*)(pageno<<12)) );

  memset ((unsigned int*) (pageno*4096), 0, 4096);
  return ((unsigned int*) (pageno*4096));
}
void release_page (unsigned int pageno) {
  int frameno = pageno_to_frameno (pageno);  // we will need this later
  if ( frameno == -1 )  { return; }          // exit if no such page
  unsigned int pdindex = pageno/1024;
  unsigned int ptindex = pageno%1024;
  page_table* pt;
  pt = (page_table*)
    ( PHYSICAL(current_pd->ptds[pdindex].frame_addr << 12) );
  // write null page descriptor
  memset (&(pt->pds[ptindex]), 0, 4);
  fill_page_desc (&(pt->pds[ptindex]), false, false, false, false, 0);
  release_frame (frameno<<12);   // expects an address, not an ID
  asm volatile ("invlpg %0" : : "m"(*(char*)(pageno<<12)) );
  // gdt_flush ();
};
void *memset (void *dest, char val, int count) {
  char *temp = (char *)dest;
  for( ; count != 0; count--) *temp++ = val;
  return dest;
}

void *memsetw (void *dest, short val, int count) {
  short *temp = (short *)dest;
  for( ; count != 0; count--) *temp++ = val;
  return dest;
}
void kputch (char c) {
  char *screen;
  
  if (c=='\n') {
    posy ++;
    posx = 0;
    uartputc ('\n');
    return;
  }
  
  if (paging_ready)
    screen = (char*) 0xb8000 + posy*160 + posx*2;
  else
    screen = (char*) 0xc0000000 + 0xb8000 + posy*160 + posx*2;
  *screen = c;
  posx++;
  if (posx == 80) {
    posy++; posx = 0;
  }

  // auf serielle Konsole schreiben; ohne Erkl�rung  
  if (c == 0x100) {  //  backspace
    uartputc('\b'); uartputc(' '); uartputc('\b');
  } else uartputc(c);
}
void clrscr () {
  posx = posy = 0;
  unsigned blank = 0x20 + (0x0f<<8);   // blank character (word)
  char *screen;
  if (paging_ready)
    screen = (char*) 0xb8000;
  else
    screen = (char*) 0xc0000000 + 0xb8000;
  memsetw (screen, blank, 80*25);
}
void *strncpy (void *dest, const void *src, int count) {
  // like memcpy, but copies only until first \0 character
  const char *sp = (const char *)src;
  char *dp = (char *)dest;
  for (; count != 0; count--) {
    *dp = *sp;
    if (*dp == 0) break;
    dp++; sp++;
  }
  return dest;
}
void hexdump (unsigned int start, unsigned int end) {
  char z;
  for (unsigned int i=start; i < end; i+=16) {
    printf ("%x  ", i);  // address
    // hex values
    for (int j=i; j<i+16; j++) {
      printf ("%02x ", (unsigned char)PEEK(j));
      if (j==i+7) kputch (' ');
    };
    kputch (' ');
    // char values
    for (int j=i; j<i+16; j++) {
      z = PEEK(j);
      if ((z>32)&&(z<127)) {
        kputch (PEEK(j));
      } else {
        kputch ('.');
      }
    }
    
    kputch ('\n');
  }
}
unsigned short inportw (unsigned short port) {
  unsigned short retval;
  asm volatile ("inw %%dx, %%ax" : "=a" (retval) : "d" (port));
  return retval;
}

void outportw (unsigned short port, unsigned short data) {
  asm volatile ("outw %%ax, %%dx" : : "d" (port), "a" (data));
}
void fill_idt_entry (unsigned char num, unsigned long address, 
    unsigned short gdtsel, unsigned char flags, unsigned char type) {
  if (num >= 0 && num < 256) {
    idt[num].addr_low  = address & 0xFFFF; // address is the handler address
    idt[num].addr_high = (address >> 16) & 0xFFFF;
    idt[num].gdtsel    = gdtsel;           // GDT sel.: user mode or kernel mode?
    idt[num].zeroes    = 0;
    idt[num].flags     = flags;
    idt[num].type      = type;
  }
}
static void set_irqmask (unsigned short mask) {
  outportb (IO_PIC_MASTER_DATA, (char)(mask % 256) );
  outportb (IO_PIC_SLAVE_DATA,  (char)(mask >> 8)  );
}

unsigned short get_irqmask () {
  return inportb (IO_PIC_MASTER_DATA) 
      + (inportb (IO_PIC_SLAVE_DATA) << 8);
}

static void enable_interrupt (int number) {
  set_irqmask ( 
    get_irqmask ()        // the current value
    & ~(1 << number)      // 16 one-bits, but bit "number" cleared
  );
}
void irq_handler (struct regs *r) {
  int number = r->int_no - 32;                      // interrupt number
  void (*handler)(struct regs *r);                  // type of handler functions

  if (number >= 8)  
    outportb (IO_PIC_SLAVE_CMD, END_OF_INTERRUPT);  // notify slave  PIC
  outportb (IO_PIC_MASTER_CMD, END_OF_INTERRUPT);   // notify master PIC

  handler = interrupt_handlers[number];
  if (handler != NULL)  handler (r);
}
void install_interrupt_handler (int irq, void (*handler)(struct regs *r)) {
  if (irq >= 0 && irq < 16)
    interrupt_handlers[irq] = handler;
}
void fault_handler (struct regs *r) {
  if (r->int_no >= 0 && r->int_no < 32) {
    printf ("'%s' (%d) Exception at 0x%08x.\n", 
      exception_messages[r->int_no], r->int_no, r->eip);        
    printf ("eflags: 0x%08x  errcode: 0x%08x\n", r->eflags, r->err_code);
    printf ("eax: %08x  ebx: %08x  ecx: %08x  edx: %08x \n",
      r->eax, r->ebx, r->ecx, r->edx);
    printf ("eip: %08x  esp: %08x  int: %8d  err: %8d \n", 
      r->eip, r->esp, r->int_no, r->err_code);
    printf ("ebp: %08x  cs: %d  ds: %d  es: %d  fs: %d  ss: %x \n",
      r->ebp, r->cs, r->ds, r->es, r->fs, r->ss);
    printf ("System Stops\n");   
    asm ("cli; \n hlt;");
  }
}
void keyboard_handler (struct regs *r) {
  unsigned char s = inportb (0x60);
  char c;
  if (s < 128)
    c = scancode_table[s];
  else
    c = 0;
  
  if (c != 0 && pos < 256) {
    buffer[pos] = c;
    printf ("%c", c);
    pos++;
    unread++;
  }
  
  return;
};
void timer_handler (struct regs *r) {
  ticks++;
  /*
  if (ticks % 10 == 0) {
    if (posy == 25) clrscr ();
    printf ("T");
  }
  */
  return;
};
void kreadline (char *s, int len) {
  int read_chars = 0;
  for (;;) {
    if (pos>0 && buffer[pos-1]=='\n') {
      buffer[pos-1] = 0;  // String terminieren
      strncpy (s, buffer, len);
      pos = 0;
      return;
    }
  }   
}
void install_syscall_handler (int syscallno, void *syscall_handler) {
  if (syscallno < MAX_SYSCALLS) 
    syscall_table[syscallno] = syscall_handler;
  return;
};
void syscall_handler (struct regs *r) {
  void (*handler) (struct regs*);   // handler is a function pointer
  int number = r->eax;
  handler = syscall_table[number];
  if (handler != 0) {
    handler (r);
  } else {
    printf ("Unknown syscall no. eax=0x%x; ebx=0x%x. eip=0x%x, esp=0x%x. "
            "Continuing.\n", r->eax, r->ebx, r->eip, r->esp);
  };
  return;
}
// Hier fuegen Sie die Implementierungen ein
int syscall1 (int eax) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax) );
  return result ;
}

int syscall2 (int eax, int ebx) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax), "b" (ebx) );
  return result ;
}

int syscall3 (int eax, int ebx, int ecx) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax), "b" (ebx), "c" (ecx) );
  return result ;
}

int syscall4 (int eax, int ebx, int ecx, int edx) {
  int result;
  asm ( "int $0x80" : "=a" (result) : "a" (eax), "b" (ebx), "c" (ecx), "d" (edx) );
  return result ;
}
int main () {
  posx = 0; posy = 8;  // set cursor
  printf ("[1] entering main()\n");

  for (int i=1; i<1024; i++) {
    fill_page_table_desc (&(current_pd->ptds[i]), false, false, false, 0);
  };
  KMAPD ( &(current_pd->ptds[  0]), (unsigned int)(current_pt)-0xC0000000 );
  KMAPD ( &(current_pd->ptds[768]), (unsigned int)(current_pt)-0xC0000000 );
  for (int i=0; i<1023; i++) {
    KMAP ( &(current_pt->pds[i]), i*4096 );
  };
  printf ("[2] page directory setup, with identity mapping\n");
  unsigned int cr0;
  char *kernel_pd_address;
  kernel_pd_address = (char*)(current_pd) - 0xC0000000;
  asm volatile ("mov %0, %%cr3" : : "r"(kernel_pd_address)); 
    // write CR3
  asm volatile ("mov %%cr0, %0" : "=r"(cr0) : );  // read  CR0
  cr0 |= (1<<31);      // Enable paging by setting PG bit 31 of CR0
  asm volatile ("mov %0, %%cr0" : : "r"(cr0) );   // write CR0
  printf ("[3] paging activated.\n");
  gdt_install ();  // replace "trick GDT" with regular GDT

  paging_ready = true;
  printf ("[4] regular GDT is active\n");
  
  memset (kernel_pt_ram, 0, 4);

  for (unsigned int fid=0; fid<NUMBER_OF_FRAMES; fid++) {
    KMAP ( &(kernel_pt_ram[fid/1024].pds[fid%1024]), fid*PAGE_SIZE );
  }
  unsigned int physaddr;
  for (int i=0; i<16; i++) {
    // get physical address of kernel_pt_ram[i]
    physaddr = (unsigned int)(&(kernel_pt_ram[i])) - 0xc0000000;
    KMAPD ( &(current_pd->ptds[832+i]), physaddr );
  };

  gdt_flush ();
    memset (ftable, 0, NUMBER_OF_FRAMES/8);  // all frames are free
    memset (ftable, 0xff, 128);
    free_frames -= 1024;
  idtp.limit = (sizeof (struct idt_entry) * 256) - 1;   // must do -1
  idtp.base  = (int) &idt;
  idt_load ();
  FILL_IDT( 0); FILL_IDT( 1); FILL_IDT( 2); FILL_IDT( 3); FILL_IDT( 4); 
  FILL_IDT( 5); FILL_IDT( 6); FILL_IDT( 7); FILL_IDT( 8); FILL_IDT( 9);
  FILL_IDT(10); FILL_IDT(11); FILL_IDT(12); FILL_IDT(13); FILL_IDT(14); 
  FILL_IDT(15); FILL_IDT(16); FILL_IDT(17); FILL_IDT(18); FILL_IDT(19);
  FILL_IDT(20); FILL_IDT(21); FILL_IDT(22); FILL_IDT(23); FILL_IDT(24);
  FILL_IDT(25); FILL_IDT(26); FILL_IDT(27); FILL_IDT(28); FILL_IDT(29);
  FILL_IDT(30); FILL_IDT(31); FILL_IDT(128);
  outportb (IO_PIC_MASTER_CMD,  0x11);  // ICW1: initialize; begin programming
  outportb (IO_PIC_SLAVE_CMD,   0x11);  // ICW1: dito, for PIC2
  outportb (IO_PIC_MASTER_DATA, 0x20);  // ICW2 for PIC1: offset 0x20 
                                        // (remaps 0x00..0x07 -> 0x20..0x27)
  outportb (IO_PIC_SLAVE_DATA,  0x28);  // ICW2 for PIC2: offset 0x28 
                                        // (remaps 0x08..0x0f -> 0x28..0x2f)
  outportb (IO_PIC_MASTER_DATA, 0x04);  // ICW3 for PIC1: there's a slave on IRQ 2 
                                        // (0b00000100 = 0x04)
  outportb (IO_PIC_SLAVE_DATA,  0x02);  // ICW3 for PIC2: your slave ID is 2
  outportb (IO_PIC_MASTER_DATA, 0x01);  // ICW4 for PIC1 and PIC2: 8086 mode
  outportb (IO_PIC_SLAVE_DATA,  0x01);
  outportb (IO_PIC_MASTER_DATA, 0x00);  // PIC1: mask 0
  outportb (IO_PIC_SLAVE_DATA,  0x00);  // PIC2: mask 0
  set_irqmask (0xFFFF);           // initialize IRQ mask
  enable_interrupt (IRQ_SLAVE);   // IRQ slave

  // flags: 1 (present), 11 (DPL 3), 0; type: 1110 (32 bit interrupt gate)
  fill_idt_entry (32, (unsigned int)irq0,  0x08, 0b1110, 0b1110);
  fill_idt_entry (33, (unsigned int)irq1,  0x08, 0b1110, 0b1110);
  fill_idt_entry (34, (unsigned int)irq2,  0x08, 0b1110, 0b1110);
  fill_idt_entry (35, (unsigned int)irq3,  0x08, 0b1110, 0b1110);
  fill_idt_entry (36, (unsigned int)irq4,  0x08, 0b1110, 0b1110);
  fill_idt_entry (37, (unsigned int)irq5,  0x08, 0b1110, 0b1110);
  fill_idt_entry (38, (unsigned int)irq6,  0x08, 0b1110, 0b1110);
  fill_idt_entry (39, (unsigned int)irq7,  0x08, 0b1110, 0b1110);
  fill_idt_entry (40, (unsigned int)irq8,  0x08, 0b1110, 0b1110);
  fill_idt_entry (41, (unsigned int)irq9,  0x08, 0b1110, 0b1110);
  fill_idt_entry (42, (unsigned int)irq10, 0x08, 0b1110, 0b1110);
  fill_idt_entry (43, (unsigned int)irq11, 0x08, 0b1110, 0b1110);
  fill_idt_entry (44, (unsigned int)irq12, 0x08, 0b1110, 0b1110);
  fill_idt_entry (45, (unsigned int)irq13, 0x08, 0b1110, 0b1110);
  fill_idt_entry (46, (unsigned int)irq14, 0x08, 0b1110, 0b1110);
  fill_idt_entry (47, (unsigned int)irq15, 0x08, 0b1110, 0b1110);
  install_interrupt_handler (IRQ_KBD, keyboard_handler);
  enable_interrupt (IRQ_KBD);
  // install_interrupt_handler (IRQ_TIMER, timer_handler);
  // enable_interrupt (IRQ_TIMER);
  printf ("ENABLE INTERRUPTS\n");
  asm ("sti");
  /*
  printf ("TEST req_frame: free_frames = %d, ", free_frames);
  int fid = request_new_frame ();
  printf ("frameid = 0x%x, free_frames = %d\n", fid, free_frames);

  printf ("TEST req_page:  free_frames = %d, ", free_frames);
  unsigned int *address = request_new_page (0);
  printf ("addr = 0x%x, free_frames = %d\n", address, free_frames);
    
  // Use new page for a string
  memset (address, 'z', PAGE_SIZE);
  char *string = (char *)address; string[10] = 0;
  printf ("Test-String of 10 'z's: %s  -- address: 0x%x\n", 
    string, (unsigned int)string);
  printf ("pageno_to_frameno (0x%x) = 0x%x\n", 
    (unsigned int)address >> 12, 
    pageno_to_frameno ((unsigned int)address >> 12));
    
  release_page ((unsigned int)address >> 12);
  printf ("After release_page (0x%x): free_frames = %d\n", 
    (unsigned int)address >> 12, free_frames);
  printf ("pageno_to_frameno (0x%x) = %d  (-1: not mapped)\n", 
    (unsigned int)address >> 12, 
    pageno_to_frameno ((unsigned int)address >> 12));
  */
  // Aufgabe 10.b.iv; diesen Teil koennen Sie loeschen
  char input[41];
  for (;;) {
    if (posy == 25) clrscr ();
    printf ("Eingabe: ");
    kreadline ((char*)input, 40);
    if (posy == 25) clrscr ();
    printf ("Ausgabe: %s\n", input);
  }


  // Tragen Sie die selbst definierten System Calls in
  // die Tabelle ein:

  // install_syscall_handler (1, function);
  // install_syscall_handler (2, function);
  // ...

   
  // Hier testen Sie die Syscalls

  for (;;);   // inifinite loop
}
