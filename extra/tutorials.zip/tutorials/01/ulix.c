// This is not Ulix yet :)

extern int printf(const char *format, ...);

int posx, posy;

void kputch (char c) {
  char *screen;
  
  if (c=='\n') {
    posy ++;
    posx = 0;
    return;
  }
  
  screen = (char*) 0xc0000000 + 0xb8000 + posy*160 + posx*2;
  *screen = c;
  posx++;
  if (posx == 80) {
    posy++; posx = 0;
  }
}

void clrscr () {
  posx = posy = 0;
  int i;
  for ( i=0; i < 80*25; i++ ) kputch (' ');
  posx = posy = 0;
}

extern char start;
extern char stack_first_address;
extern char stack_last_address;

#define COPY_ESP_TO_VAR(x)  asm volatile ("mov %%esp, %0" : "=r"(x)          )

int main () {
  // for (;;); 

  // clrscr ();
  posx = 0; posy = 12;
  printf ("Hello World! This is not Ulix yet :) \n\n");
  printf ("address of main() [ulix.c]:    %08x\n", main);
  printf ("address of start  [start.asm]: %08x\n", &start);

  printf ("stack: %08x - %08x\n", &stack_first_address, &stack_last_address);

  for (;;);   // inifinite loop
}

